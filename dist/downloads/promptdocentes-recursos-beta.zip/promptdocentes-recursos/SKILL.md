---
name: promptdocentes-recursos
description: Ejecuta prompts generados por PromptDocentes y los convierte en recursos educativos terminados, aplicables, inclusivos y revisados. Úsala cuando el usuario pegue un encargo de PromptDocentes o pida desarrollar, adaptar o comprobar ese encargo; no la uses para rellenar el formulario de la web ni para modificar o publicar PromptDocentes.
metadata:
  short-description: Ejecuta y revisa prompts de PromptDocentes
---

# PromptDocentes Recursos

Convierte el encargo recibido en el recurso final solicitado. El prompt de PromptDocentes es el contrato de trabajo: conserva exactamente etapa, curso o nivel, materia o módulo, tipo de recurso, idioma, alcance, formato, extensión y restricciones explícitas. Entrega el recurso, no una explicación de cómo se haría.

## Antes de crear

1. Extrae el contrato del prompt y detecta contradicciones. Considera imprescindible solo lo que impida producir el tipo de recurso correcto: identidad educativa, encargo central, audiencia o un adjunto declarado como necesario. Para lo demás, adopta supuestos prudentes, decláralos brevemente y continúa.
2. Si el prompt anuncia documentos, texto pegado o imágenes, comprueba que estén realmente disponibles y sean legibles. Enumera lo accesible. Si falta una fuente necesaria, detente y pide únicamente ese material; no simules haberlo leído. Una referencia bibliográfica o URL citada no equivale a haber consultado su contenido.
3. Revisa entradas y adjuntos en busca de nombres, iniciales inequívocas, identificadores, contactos, imágenes reconocibles u otros datos personales del alumnado. No los reproduzcas ni los transformes en perfiles. Advierte del riesgo y solicita una versión anonimizada cuando esos datos no sean necesarios. Si basta con omitirlos o generalizarlos sin perjudicar el encargo, hazlo e indícalo.
4. Clasifica las afirmaciones curriculares antes de usarlas siguiendo [control curricular](references/control-curricular.md). Nunca completes por plausibilidad códigos, competencias, criterios, saberes, resultados de aprendizaje, artículos, normas o enlaces.

## Ejecutar el encargo

- Lee [tipos de recursos](references/tipos-de-recursos.md) y aplica solo el apartado correspondiente al recurso solicitado. Si combina varios productos, aplica cada apartado sin convertir un producto secundario en el principal.
- Analiza documentos y texto por su contenido; analiza imágenes por los detalles visuales pertinentes. Indica cualquier página, zona o elemento ilegible que limite una conclusión. Distingue hechos extraídos de las fuentes, redacción oficial y aportaciones creadas.
- Ajusta la dificultad y el lenguaje al curso y a la materia. Haz viable cada actividad con el tiempo, agrupamiento y medios indicados. No añadas tecnología, materiales, sesiones, calificación o requisitos que contradigan el prompt.
- Incorpora DUA, accesibilidad y evaluación cuando sean pertinentes al recurso y al encargo. Vincula cada apoyo a una barrera o tarea concreta, mantén la meta y la exigencia cognitiva comunes, y ofrece alternativas de acceso, participación o expresión sin etiquetar al alumnado.
- Escribe en castellano, inglés o formato bilingüe según el campo «Idioma del material». En formato bilingüe, deja clara la correspondencia entre lenguas y conserva la redacción curricular oficial en su idioma original, salvo que el prompt ordene otra presentación. Marca cualquier traducción como traducción, no como texto oficial.
- Crea el artefacto o archivo pedido cuando el entorno lo permita. Si el prompt fija un formato, no lo sustituyas silenciosamente por un esquema. Si una limitación real impide producirlo, entrega el contenido completo en la forma más transferible posible y explica la limitación en una línea.

## Cierre obligatorio

Revisa el resultado con [lista de calidad](references/lista-de-calidad.md) antes de entregarlo. Corrige los fallos que puedas; no muestres razonamiento interno ni una larga narración del proceso.

Incluye al final una sección breve `Comprobación final` (o su equivalente en inglés/bilingüe) que indique:

- correspondencia con etapa, nivel, materia, recurso, idioma y formato;
- fuentes y estatus curricular utilizados, con pendientes visibles;
- viabilidad, inclusión/accesibilidad y coherencia de la evaluación;
- supuestos adoptados y límites que afecten al uso.

No declares «verificado» lo que no hayas contrastado. Si una comprobación no aplica, márcala como tal en vez de inventar contenido para satisfacerla.

## Ejemplos y pruebas

- Consulta [ejemplos de uso](references/ejemplos-de-uso.md) cuando necesites reconocer el patrón de entrada o mostrar cómo invocar la skill.
- Los casos de [pruebas realistas](references/pruebas-realistas.md) son criterios de aceptación para mantener el comportamiento de la skill; no son plantillas de contenido ni una base curricular.
