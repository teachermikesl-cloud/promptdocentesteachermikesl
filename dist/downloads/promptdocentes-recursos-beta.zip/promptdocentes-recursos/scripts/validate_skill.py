#!/usr/bin/env python3
"""Comprueba invariantes locales de la skill PromptDocentes Recursos."""

from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
ENTRY = ROOT / "SKILL.md"
REQUIRED_REFERENCES = {
    "control-curricular.md",
    "tipos-de-recursos.md",
    "lista-de-calidad.md",
    "ejemplos-de-uso.md",
    "pruebas-realistas.md",
}


def fail(message: str) -> None:
    print(f"ERROR: {message}")
    raise SystemExit(1)


def main() -> None:
    text = ENTRY.read_text(encoding="utf-8")
    if "name: promptdocentes-recursos" not in text:
        fail("el nombre de la skill no coincide")
    if "TODO" in text or "[TODO" in text:
        fail("quedan marcadores de plantilla")

    refs = ROOT / "references"
    missing = sorted(name for name in REQUIRED_REFERENCES if not (refs / name).is_file())
    if missing:
        fail("faltan referencias: " + ", ".join(missing))
    for name in REQUIRED_REFERENCES:
        if f"references/{name}" not in text:
            fail(f"SKILL.md no enlaza {name}")

    cases = (refs / "pruebas-realistas.md").read_text(encoding="utf-8")
    case_count = len(re.findall(r"^## Caso \d+", cases, flags=re.MULTILINE))
    if case_count < 5:
        fail("se requieren al menos cinco pruebas realistas")
    if cases.count("**Aceptación**") != case_count:
        fail("cada caso debe incluir criterios de aceptación")

    curriculum = (refs / "control-curricular.md").read_text(encoding="utf-8")
    for status in (
        "INCORPORADO_EN_PROMPT",
        "APORTADO_POR_DOCENTE",
        "VERIFICADO_EN_FUENTE_OFICIAL",
        "PENDIENTE_DE_VERIFICAR",
        "PROPUESTA_IA",
    ):
        if status not in curriculum:
            fail(f"falta el estado curricular {status}")

    print(f"OK: estructura, referencias, {case_count} casos y control curricular válidos")


if __name__ == "__main__":
    try:
        main()
    except (OSError, UnicodeError) as exc:
        fail(str(exc))
