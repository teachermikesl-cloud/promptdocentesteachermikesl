# Ejemplos de uso

## Invocación directa

```text
Usa $promptdocentes-recursos para ejecutar el siguiente prompt generado por PromptDocentes. Necesito el recurso terminado en el formato que indica.

[pegar aquí el prompt completo]
```

Si el prompt anuncia archivos, se adjuntan en el mismo mensaje o antes de pedir que empiece.

## Con documentos

```text
Usa $promptdocentes-recursos con el prompt de PromptDocentes que pego a continuación. Adjunto “tema-4.pdf” como contenido de referencia y “plantilla.docx” únicamente como modelo de formato. Mantén ambas funciones separadas.

[prompt]
```

Comportamiento esperado: la skill enumera ambos archivos, comprueba que puede leerlos, atribuye correctamente el contenido y el estilo, y no presenta la plantilla como fuente curricular.

## Revisión de un recurso ya generado

```text
Usa $promptdocentes-recursos para comprobar y corregir este recurso frente a su prompt original de PromptDocentes. Conserva el formato y marca cualquier referencia curricular que no pueda justificarse.

[prompt original]
[recurso o archivo]
```

Comportamiento esperado: corrige desajustes, conserva decisiones válidas y entrega una versión final, con pendientes explícitos en lugar de códigos plausibles.

## Prompt bilingüe

```text
Usa $promptdocentes-recursos para ejecutar este encargo bilingüe. El material del alumnado debe aparecer en inglés y castellano; las referencias curriculares oficiales deben mantenerse en español y claramente separadas de la traducción funcional.

[prompt]
```

Comportamiento esperado: las dos lenguas se corresponden, las traducciones no se presentan como redacción oficial y la comprobación final también verifica esa correspondencia.
