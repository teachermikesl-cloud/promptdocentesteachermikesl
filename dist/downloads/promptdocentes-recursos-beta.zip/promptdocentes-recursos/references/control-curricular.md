# Control curricular y de fuentes

## Registro de procedencia

Clasifica cada elemento que vaya a aparecer como oficial en uno de estos estados:

| Estado | Qué significa | Uso permitido |
|---|---|---|
| `INCORPORADO_EN_PROMPT` | El prompt transcribe el elemento y lo identifica como currículo oficial incorporado. | Usar la transcripción, conservar código y sentido, y citar la fuente que figure en el prompt. No atribuir una comprobación externa no realizada. |
| `APORTADO_POR_DOCENTE` | El contenido está en un adjunto o texto que sí se ha podido leer. | Usar y atribuir al archivo o bloque correspondiente. No elevarlo automáticamente a redacción oficial. |
| `VERIFICADO_EN_FUENTE_OFICIAL` | Se ha abierto la fuente oficial exacta y coincide etapa, curso, materia o módulo y anexo. | Citar con precisión y, si procede, reproducir fragmentos breves respetando la fuente. |
| `PENDIENTE_DE_VERIFICAR` | Solo hay una mención, enlace no abierto, fuente secundaria, anexo ausente, discrepancia o elemento incompleto. | Mantener visible como pendiente. No usarlo como base de códigos o redacción oficial. |
| `PROPUESTA_IA` | Resumen, interpretación, secuencia, actividad, evidencia, descriptor o adaptación creados para el recurso. | Usar como propuesta profesional, separada de lo oficial y de lo aportado. |

No hace falta mostrar siempre estas etiquetas literales. Sí debe resultar inequívoco qué procede de cada capa.

## Reglas de decisión

- La etiqueta del prompt «redacción oficial», junto con fuente y transcripción incorporada, permite tratar el bloque como `INCORPORADO_EN_PROMPT`; no equivale a `VERIFICADO_EN_FUENTE_OFICIAL` por la ejecución actual.
- Una norma general de etapa no prueba por sí sola los elementos de una materia. En FP, el catálogo o la ordenación general no prueban los resultados de aprendizaje y criterios del módulo exacto.
- Una coincidencia de nombre no autoriza a reutilizar elementos de otra materia, módulo, título, curso, ciclo o comunidad autónoma.
- Conserva anomalías, ausencias o advertencias declaradas en la fuente. No las repares por inferencia.
- Si el prompt ordena usar solo referencias del docente, no añadas otras fuentes. Si ordena no incluir referencias curriculares, trabaja con objetivos educativos sin introducir normativa ni códigos.
- Si hay discrepancias, presenta ambas lecturas con su procedencia y marca el conflicto; no elijas silenciosamente una.

## Separación en la salida

Cuando el recurso incluya contenido curricular, usa una estructura equivalente a:

1. **Redacción oficial o transcripción incorporada**: texto y códigos sin mezclarlos con paráfrasis.
2. **Resumen o interpretación didáctica**: formulación propia, identificada como tal.
3. **Propuesta de aplicación o evidencia**: decisiones profesionales creadas para el grupo.
4. **Pendientes de verificación**: elementos no localizados, no legibles o aún no comprobados.

En tablas, utiliza columnas separadas. En prosa, utiliza apartados o etiquetas claras.

## Cuándo preguntar

Pregunta solo si la ausencia bloquea el encargo, por ejemplo:

- el prompt exige usar un documento o imagen y no está disponible;
- falta etapa, nivel o materia y esa elección cambia sustancialmente el contenido;
- se solicita alineación o reproducción curricular, pero el bloque pertinente no está incorporado ni se dispone de la fuente exacta;
- dos instrucciones obligatorias son incompatibles.

No preguntes por preferencias menores que puedas resolver con una opción prudente y explícita.
