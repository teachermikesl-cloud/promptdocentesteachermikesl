# Tipos de recursos

Aplica la fila o apartado que corresponda. Estos son mínimos de utilidad, no una obligación de añadir secciones que el prompt excluya.

## Planificación

| Recurso | El resultado debe resolver |
|---|---|
| Programación anual | Cobertura del curso, temporalización viable, mapa de unidades, progresión, trazabilidad curricular, evaluación, recuperación e inclusión. Si el prompt exige aprobación previa del mapa, entrega primero solo ese mapa y espera. |
| Situación de aprendizaje | Reto auténtico que sostenga la secuencia, producto, fases, actividades, recursos, evidencias individuales y relación criterio–actividad–instrumento. |
| Unidad didáctica o de trabajo | Propósito, contenidos, sesiones, explicación, práctica guiada, aplicación, evaluación, recuperación y materiales. Usa terminología propia del modelo: no llames situación de aprendizaje a una unidad de trabajo de FP salvo instrucción expresa. |
| Sesión | Guion aplicable con minutos que sumen la duración, preparación, acciones del docente y alumnado, observación/evidencia, apoyos y plan de cierre. |
| Proyecto o ABP | Pregunta guía, fases, hitos, roles con funciones reales, recursos, producto auténtico, seguimiento y evidencia individual dentro del trabajo colectivo. |

## Materiales

| Recurso | El resultado debe resolver |
|---|---|
| Ficha o cuaderno | Consignas listas para el alumnado, progresión, estímulos completos, espacio o formato de respuesta, apoyos y soluciones separadas para el docente. |
| Presentación o guion visual | Narrativa por diapositivas, una idea principal por pantalla, texto visible, propuesta visual, participación frecuente, notas del presentador y accesibilidad. |
| Infografía u organizador | Jerarquía y relaciones visuales, texto exacto, composición, lectura rápida, contraste y texto alternativo. |
| Comprensión oral | Objetivo de escucha, guion natural ajustado al nivel, preescucha, escucha global y detallada, pauta de locución, transcripción, soluciones y apoyos. Si se pide audio, genera el archivo cuando sea posible. |
| Cómic educativo | Sinopsis, personajes, continuidad, guion por viñetas, diálogo breve, dirección visual, texto alternativo y prompt de producción cuando proceda. |
| Imagen educativa | Función didáctica, composición, elementos obligatorios/prohibidos, estilo, proporción, texto visible exacto, texto alternativo y activo visual final o prompt de generación según el encargo. |
| Vídeo educativo | Objetivo, duración, guion de voz, storyboard temporizado, planos/recursos, rótulos, subtítulos, accesibilidad y plan de edición; genera el medio cuando se solicite y sea posible. |
| Actividad interactiva | Objetivo, mecánica, reglas, flujo y estados, contenido completo, retroalimentación explicativa, navegación por teclado, contraste, alternativas accesibles, reinicio y criterio de finalización. |

## Currículo y evaluación

| Recurso | El resultado debe resolver |
|---|---|
| Mapa curricular | Alcance completo solicitado, códigos conservados, separación entre redacción oficial, resumen y evidencias propuestas, más ausencias o anomalías visibles. No entregar una muestra cuando se pide totalidad. |
| Rúbrica | Evidencia o producto evaluado, criterios observables, niveles progresivos con el mismo foco, descriptores positivos, uso e interpretación; puntuación solo si se solicita o es necesaria. |
| Prueba o cuestionario | Tabla de especificaciones cuando proceda, instrucciones, variedad cognitiva, preguntas inequívocas, puntuación coherente, soluciones razonadas, retroalimentación y accesibilidad. |
| Instrumentos de evaluación | Relación criterio–evidencia–instrumento, registro usable, diferencia entre evaluación formativa y calificación, momentos, agentes y recuperación. |

## Inclusión y apoyo

| Recurso | El resultado debe resolver |
|---|---|
| Adaptación DUA | Barrera concreta, tarea afectada, apoyo de acceso/participación/expresión, meta común, exigencia cognitiva conservada y forma de comprobar su eficacia. |
| Refuerzo o ampliación | En refuerzo, localizar la dificultad, modelar, reducir carga extrínseca y retirar apoyos. En ampliación, abrir decisiones, demostración, transferencia o creación útil; no añadir solo más ejercicios. |

## Comunicación y otros

| Recurso | El resultado debe resolver |
|---|---|
| Comunicación con familias | Pieza lista para enviar o usar, propósito y llamada a la acción claros, tono respetuoso, hechos observables separados de interpretaciones, acuerdos y próximos pasos; sin datos sensibles innecesarios. |
| Tutoría y convivencia | Clima seguro, participación no forzada, instrucciones, límites, tratamiento de situaciones delicadas, cierre reflexivo y vías de ayuda. |
| Corrección y feedback | Logro, evidencia concreta, siguiente paso, indicación accionable y oportunidad de revisión; sin etiquetas personales ni atribución de intenciones. |
| Recurso personalizado | Deriva la estructura de su uso real, audiencia, restricciones, soporte final y criterios de éxito. Mantén todos los controles comunes de la skill. |

## Reglas transversales de diseño

- La metodología debe existir en las acciones, agrupamientos y responsabilidades, no solo como etiqueta.
- La evaluación debe recoger evidencias posibles dentro de la actividad; si hay calificación individual, debe existir evidencia individual.
- Los descriptores expresan conductas o productos observables. La retroalimentación explica el error y el siguiente paso.
- Las medidas inclusivas nombran barrera y momento de uso. Evita bajar el reto común salvo que el encargo establezca una adaptación curricular distinta con respaldo suficiente.
- Todo elemento necesario para aplicar el recurso debe estar incluido o identificado de forma operativa: textos, datos, materiales, soluciones, preparación y tiempos.
