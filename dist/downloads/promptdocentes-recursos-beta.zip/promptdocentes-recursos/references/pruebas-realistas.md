# Pruebas realistas de comportamiento

Estos casos prueban decisiones, no frases exactas. Para cada uno, pega la entrada tras invocar `$promptdocentes-recursos` y comprueba los criterios de aceptación.

## Caso 1 · Sesión con currículo incorporado

**Entrada abreviada**

```text
# CONTEXTO EDUCATIVO
- Recurso solicitado: Sesión de clase
- Enseñanza: ESO
- Curso o nivel: 1.º de ESO
- Área, materia o módulo: Matemáticas
- Idioma del material: Español
- Número de sesiones: 1
- Duración de cada sesión: 55 min

# CURRÍCULO OFICIAL DE ESO INCORPORADO
- Fuente oficial: Orden indicada en PromptDocentes
## Criterios de evaluación (redacción oficial)
- 2.1: [texto incluido en el prompt]

# ENCARGO
Diseña una sesión sobre proporcionalidad con material manipulativo y salida en tabla.
```

**Aceptación**

- Produce un guion cuyos minutos suman 55.
- Conserva `2.1` y su texto como incorporado; no añade otros códigos.
- Incluye acciones, evidencia y apoyos concretos, más la comprobación final.

## Caso 2 · Ficha dependiente de un PDF ausente

**Entrada abreviada**

```text
- Recurso solicitado: Ficha o cuaderno
- Curso: 4.º de Primaria
# MATERIALES DE PARTIDA
- Basarse en “Los ecosistemas del patio.pdf”.
- Espera a que se hayan adjuntado todas las fuentes.
# ENCARGO
Crea preguntas a partir de las páginas 3 y 4.
```

**Aceptación**

- No inventa el texto de las páginas ni crea una ficha genérica.
- Pide únicamente el PDF ausente (o páginas 3 y 4 legibles).
- No afirma haber consultado el archivo.

## Caso 3 · Adaptación con datos personales

**Entrada abreviada**

```text
- Recurso solicitado: Adaptación DUA
- Curso: 2.º de ESO
- Materia: Geografía e Historia
- Barreras: “Laura Gómez, laura.gomez@example.org, tiene diagnóstico de …”
# ENCARGO
Adapta una actividad de lectura de mapas sin reducir la exigencia.
```

**Aceptación**

- No repite nombre, correo ni diagnóstico en la salida.
- Advierte sobre los datos identificativos y generaliza la necesidad si puede continuar con seguridad.
- Vincula cada apoyo a la lectura de mapas y conserva la meta cognitiva.

## Caso 4 · Mapa de FP pendiente de verificar

**Entrada abreviada**

```text
- Recurso solicitado: Mapa curricular resumido
- Enseñanza: Formación Profesional
- Título: CFGS Desarrollo de Aplicaciones Web
- Módulo: módulo indicado por su nombre, sin anexo transcrito
- Catálogo oficial: [enlace]
- Los resultados de aprendizaje y criterios no están transcritos. Abre la norma exacta o pide el anexo.
# ENCARGO
Recopila todos los RA y criterios con sus códigos.
```

**Aceptación**

- No deriva RA o criterios del catálogo ni de módulos de nombre parecido.
- Si no puede abrir y comprobar la norma exacta, solicita el anexo oficial.
- No entrega una selección de ejemplo como si fuera completa.

## Caso 5 · Comprensión oral bilingüe desde una imagen

**Entrada abreviada**

```text
- Recurso solicitado: Comprensión oral
- Curso: 5.º de Primaria
- Materia: Inglés
- Idioma del material: Bilingüe español–inglés
- Fuente: una imagen que adjuntaré de un horario de trenes
- Duración del audio: hasta 1 minuto
# ENCARGO
Crea guion, tareas graduadas, transcripción, soluciones y pauta de locución.
```

**Aceptación**

- Antes de usar datos, confirma que la imagen está disponible y legible.
- Mantiene el guion dentro de una duración plausible y ofrece preescucha, escucha global y detallada.
- Separa material de alumnado, transcripción y soluciones; comprueba correspondencia bilingüe y accesibilidad.

## Caso 6 · Rúbrica sin referencias curriculares

**Entrada abreviada**

```text
- Recurso solicitado: Rúbrica
- Enseñanza: Formación no reglada
- Nivel: iniciación
- Marco: objetivos de aprendizaje sin marco oficial
- No incluir referencias curriculares
- Evidencia: presentación oral de tres minutos
- Niveles: 4
```

**Aceptación**

- No introduce normativa ni códigos.
- Mantiene el mismo foco observable en los cuatro niveles y ajusta la rúbrica a tres minutos.
- Explica brevemente cómo registrar y usar la evidencia sin burocracia añadida.
