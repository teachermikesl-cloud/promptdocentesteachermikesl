# Lista de calidad final

Realiza esta revisión sobre el recurso terminado y corrige antes de entregar.

## Correspondencia

- Coinciden etapa, curso/nivel, materia/módulo, comunidad o marco, tipo de recurso, destinatarios, idioma, extensión y formato.
- Se han respetado cantidades y límites: sesiones, minutos, preguntas, niveles, viñetas, diapositivas, duración, proporción o tamaño.
- La salida es el producto terminado y contiene todos los componentes solicitados.

## Fuentes y currículo

- Cada fuente anunciada está disponible y ha sido realmente leída, o figura como ausente/ilegible.
- Redacción oficial, datos aportados, interpretaciones y propuestas de IA están separados.
- Ningún código, elemento curricular, resultado de aprendizaje, norma, artículo, cita o URL ha sido inventado, reconstruido o trasladado desde otro contexto.
- Los elementos pendientes y las discrepancias permanecen visibles.
- La alineación criterio–actividad–evidencia–instrumento es explícita y defendible cuando aplica.

## Aplicabilidad pedagógica

- Tiempos y cargas son realistas; en una sesión, los minutos cuadran.
- Las instrucciones permiten actuar sin adivinar pasos; se incluyen estímulos, materiales y soluciones necesarios.
- El nivel cognitivo y lingüístico encaja con el alumnado y progresa con sentido.
- Metodologías, roles y productos tienen una función real, no decorativa.
- La evaluación observa lo enseñado y practicado, distingue feedback de calificación y prevé recuperación cuando corresponde.

## Inclusión, accesibilidad y privacidad

- Cada apoyo responde a una barrera o tarea concreta y conserva la meta común.
- Hay alternativas pertinentes de representación, acción/expresión o participación, sin sobrecargar el recurso.
- Se contemplan contraste, legibilidad, texto alternativo, subtítulos/transcripción, navegación y lenguaje claro según el soporte.
- No aparecen datos identificativos del alumnado ni inferencias diagnósticas. Las comunicaciones delicadas usan hechos observables y el mínimo dato necesario.

## Integridad editorial

- No hay contradicciones entre objetivos, secuencia, evaluación, soluciones y comprobación final.
- No hay tablas vacías, marcadores de posición, promesas de completar después ni referencias a adjuntos inexistentes.
- El castellano o inglés es correcto y consistente. En bilingüe, ambas versiones se corresponden y la lengua oficial de las fuentes se conserva o se identifica.
- Los supuestos y limitaciones materiales se declaran con brevedad y no se presentan como hechos.

## Resultado de la auditoría

En `Comprobación final`, resume solo los resultados útiles para el docente. No vuelques toda esta lista ni afirmes perfección absoluta. Usa formulaciones como «comprobado», «no aplica» o «pendiente: …» con base real.
