# Contrato del proyecto de curso

## Archivo de entrada

El proyecto usa `00_control/curso.json`, codificado en UTF-8. Es la fuente de verdad de las decisiones aprobadas.

Campos mínimos:

```json
{
  "schema_version": "1.0",
  "project": {"title": "", "academic_year": "", "owner": "Teacher MikeSL", "status": "draft"},
  "context": {"territory": "Andalucía", "stage": "", "level": "", "subject": "", "language": "es"},
  "curriculum": {"model": "competency", "sources": [], "competencies": [], "evaluation_criteria": [], "core_learning": []},
  "learners": {"profile": "", "access_needs": [], "interests": []},
  "design": {"weekly_sessions": 0, "estimated_weeks": 0, "methodological_choices": [], "assessment_choices": []},
  "sequence_map": [],
  "outputs": {"teacher_guides": true, "learner_materials": true, "assessment_tools": true, "accessible_alternatives": true, "interactive_resources": false}
}
```

Cada fuente curricular usa:

```json
{"id": "SRC-001", "title": "", "url": "https://...", "issuer": "", "scope": "", "status": "verified", "checked_on": "AAAA-MM-DD"}
```

Cada secuencia usa `icon` de forma opcional para la vista docente:

```json
{"id": "SEQ-01", "term": 1, "title": "", "icon": "📚", "central_learning": "", "performance_or_product": "", "sessions": 0, "competency_ids": [], "criterion_ids": [], "status": "planned"}
```

## Estructura de salida

```text
00_control/
  curso.json
  decisiones.md
  fuentes.csv
  estado.json
  validacion.json
10_diseno_anual/
  programacion-anual.md
  mapa-curricular.csv
  plan-evaluacion.md
  inclusion-accesibilidad.md
20_secuencias/
  SEQ-01/
    guia-docente.md
    material-alumnado.md
    evaluacion.csv
    recursos/
30_recursos_comunes/
  instrumentos/
  plantillas/
90_entrega/
  indice.md
  manifest.json
  📦 Proyecto docente/
```

Los documentos editables son los originales canónicos. Los PDF, páginas web u otros formatos publicados son derivados y deben poder regenerarse.

La carpeta `📦 Proyecto docente` es una vista derivada y navegable. Se crea con `coursekit.py present` siguiendo [la presentación visual](presentacion-entrega.md); sus iconos complementan el texto y no sustituyen la numeración ni la descripción.

## Estados

- `draft`: datos incompletos.
- `curriculum_checked`: fuentes oficiales comprobadas.
- `map_approved`: mapa anual aprobado por el docente.
- `pilot_approved`: piloto completo aprobado.
- `production`: generación por bloques.
- `validated`: comprobaciones obligatorias superadas.
- `released`: copia de entrega creada.
