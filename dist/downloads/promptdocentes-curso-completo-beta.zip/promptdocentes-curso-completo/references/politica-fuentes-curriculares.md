# Política de fuentes curriculares

## Jerarquía

1. Boletines y portales normativos oficiales: BOE, BOJA y organismos públicos competentes.
2. Currículos y anexos oficiales publicados por la administración educativa.
3. Orientaciones institucionales claramente identificadas como no normativas.
4. Fuentes secundarias solo para localizar la fuente oficial, nunca para sustituirla.

## Registro mínimo

Para cada fuente conservar título, organismo, URL directa, ámbito, fecha de consulta, estado de verificación y qué datos se extrajeron. Una URL de buscador o una noticia no equivale a una fuente verificada.

## Tratamiento de los datos

- Mantener literalmente códigos y denominaciones cuando sea necesario para la trazabilidad.
- Identificar las paráfrasis como resúmenes.
- No mezclar elementos de cursos, materias, etapas o versiones normativas distintas.
- En caso de modificación o derogación, documentar qué versión resulta aplicable al curso académico.
- No declarar que se ha incorporado “todo el currículo” sin una comprobación de cobertura.

## Reutilización

Los textos legales y datos públicos pueden estar sujetos a condiciones de reutilización, atribución e integridad. Conservar la atribución y el enlace oficial, evitar logotipos institucionales no autorizados y no sugerir respaldo de la Junta de Andalucía.
