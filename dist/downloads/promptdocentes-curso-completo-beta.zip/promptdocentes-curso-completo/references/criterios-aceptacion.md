# Criterios de aceptación

## Currículo

- Toda competencia y criterio empleado existe en una fuente oficial registrada.
- Los códigos y denominaciones no se asignan a otra materia o nivel.
- Cada criterio aparece al menos en una secuencia o figura como exclusión justificada.
- Cada secuencia identifica las evidencias observables con las que se evaluará.

## Diseño anual

- Las sesiones planificadas caben en el calendario declarado.
- La progresión no presupone aprendizajes que aún no se han trabajado.
- Productos y actividades son viables con los recursos y el contexto indicados.
- El mapa anual fue aprobado antes de producir todo el curso.

## Secuencias

- Objetivos, actividades, evidencias, criterios e instrumentos mantienen trazabilidad.
- Guía docente y materiales del alumnado coinciden en tiempos, consignas y entregables.
- Las adaptaciones no reducen automáticamente el aprendizaje evaluado.
- Los recursos digitales tienen alternativa accesible cuando sea necesaria.

## Integridad técnica

- No hay archivos vacíos, marcadores TODO ni enlaces locales rotos en la entrega.
- Los nombres de archivo son seguros en Windows, macOS y Linux.
- El manifiesto coincide con los archivos entregados.
- Los derivados abren correctamente y conservan el contenido canónico.
- La vista docente contiene un índice legible y solo enlaza archivos existentes.
- Las carpetas y archivos de la vista docente combinan orden numérico, texto comprensible e iconos no ambiguos.

## Presentación

- La navegación permite localizar guía docente, materiales, evaluación y recursos sin conocer la estructura técnica.
- Los documentos mantienen jerarquía visual, títulos informativos, legibilidad y espacios consistentes.
- Los iconos ayudan a reconocer categorías, pero ninguna información depende exclusivamente de ellos.
- La identidad de PromptDocentes es propia y no reproduce plantillas, marcas o elementos distintivos de terceros.

## Transparencia

- Se diferencian datos aportados, fuentes verificadas, decisiones docentes y propuestas generadas.
- Se enumeran limitaciones y elementos pendientes.
- No contiene datos personales de alumnado ni material de terceros sin permiso compatible.
