# Presentación visual de la entrega

## Principio

El proyecto mantiene dos capas:

1. **Capa técnica canónica:** carpetas numeradas y nombres estables usados para validar, actualizar y regenerar el proyecto.
2. **Vista docente:** copia organizada dentro de `90_entrega/📦 Proyecto docente`, con iconos, nombres naturales e índice de navegación.

La vista docente no sustituye los originales canónicos. Se regenera desde ellos para evitar versiones divergentes; cualquier edición manual realizada dentro de `📦 Proyecto docente` se reemplaza en la siguiente generación y, por tanto, debe hacerse en el original canónico.

## Arquitectura visual predeterminada

```text
📦 Proyecto docente/
├── 🧭 00 · Empieza aquí/
│   ├── 🧭 Índice visual.md
│   └── 🧭 Panel de navegación.html
├── 🗺️ 10 · Diseño anual/
│   ├── 📅 Mapa anual.md
│   └── 🧩 Mapa curricular.csv
├── 🍂 20 · 1.er trimestre/
├── ❄️ 30 · 2.º trimestre/
├── 🌱 40 · 3.er trimestre/
└── 📜 80 · Fuentes y verificación/
```

Cada secuencia terminada aparece en su trimestre con un icono configurable y, como mínimo:

```text
🤝 SEQ-04 · Título/
├── 📘 Guía docente/
│   ├── 📘 Guía docente.docx
│   ├── 🧭 Guía paso a paso.docx
│   └── 📘 Guía docente.md
├── ✏️ Material del alumnado/
│   ├── ✏️ Material del alumnado.docx
│   └── ✏️ Material del alumnado.md
├── 🎯 Evaluación/
│   ├── 🎯 Evaluación y soluciones.docx
│   ├── 📊 Registro de evaluación.xlsx
│   └── 🎯 Matriz de evaluación.csv
├── 🧩 Apoyos y accesibilidad/
│   ├── 🛟 Refuerzo y apoyo.docx
│   └── 🧩 Apoyos y accesibilidad.docx
├── 🚀 Ampliación y enriquecimiento/
│   └── 🚀 Ampliación y enriquecimiento.docx
└── 🧰 Recursos/
    └── 🎲 Tarjetas de retos.docx
```

## Reglas de nombres e iconos

- El número conserva el orden aunque el sistema no interprete emojis.
- El texto explica siempre el significado; el icono nunca es la única etiqueta.
- Utilizar un solo icono por nombre y evitar cadenas decorativas.
- No usar color o iconos como única forma de comunicar estado, dificultad o accesibilidad.
- Mantener nombres compatibles con Windows, macOS y Linux; evitar `/`, `\\`, `:`, `*`, `?`, comillas, `<`, `>` y `|`.
- Cada secuencia puede declarar `icon` en `sequence_map`; si falta, usar `📚`.

## Estilo de los documentos

- Abrir con título, etapa, curso, materia, duración y propósito.
- Mantener jerarquía de encabezados breve y predecible.
- Usar tablas solo cuando faciliten comparación o aplicación.
- Resaltar consignas, seguridad, evidencias y decisiones docentes con etiquetas claras, no con decoración aislada.
- Aplicar lenguaje cercano, contraste suficiente, tipografía legible y espacio en blanco.
- Mantener una identidad común y diferenciar cada familia por función: azul marino para planificación docente, verde azulado para aplicación sesión a sesión, azul claro para alumnado, magenta para evaluación, ámbar para tarjetas, verde para refuerzo, violeta para ampliación y morado para accesibilidad.
- Cambiar también el arquetipo, no solo el color: la guía docente prioriza trazabilidad y tablas de sesiones; la guía de aplicación ofrece una sesión por página; el material del alumnado deja espacio para responder; la evaluación usa formato apaisado cuando mejora la comparación; apoyo, ampliación y accesibilidad incluyen decisiones y registros específicos.
- En DOCX, PDF o HTML derivados, aplicar estilos de título consistentes, alto contraste y cabecera o pie discretos con `PromptDocentes · Teacher MikeSL`.
- No incrustar datos personales, fotografías del alumnado, diagnósticos ni activos de terceros sin autorización y licencia compatible.

## Generación

Crear o actualizar la vista docente después de validar los originales:

```bash
python3 scripts/build_polished_docs.py --project <ruta> --sequence <SEQ-XX>
NODE_PATH=<node_modules> node scripts/build_assessment_workbook.cjs --project <ruta> --sequence <SEQ-XX>
python3 scripts/coursekit.py present --project <ruta>
python3 scripts/coursekit.py manifest --project <ruta>
```

Antes de entregar, abrir el índice visual y comprobar que los archivos enlazados existen. Los formatos derivados atractivos se generan solo después de aprobar el contenido canónico.
