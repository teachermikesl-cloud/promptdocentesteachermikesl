---
name: promptdocentes-curso-completo
description: Diseña, produce y verifica un proyecto docente anual completo a partir de una especificación aprobada, con mapa curricular trazable, secuencias de aprendizaje, materiales, evaluación, accesibilidad y paquete final organizado. Úsala cuando el usuario pida crear una programación y sus recursos para todo un curso, continuar un proyecto anual ya iniciado o auditar que un paquete educativo esté completo; no para generar un único recurso aislado ni para modificar la web PromptDocentes.
license: LicenseRef-Proprietary-Beta
---

# PromptDocentes · Curso completo

Construye un proyecto anual como una colección coherente de recursos reales. Trabaja por hitos verificables para evitar producir decenas de archivos sobre decisiones incorrectas.

## Mantener independencia y trazabilidad

- Crear contenido, código, nombres, plantillas y estructura propios.
- No copiar ni adaptar código, plantillas, textos, ejemplos, identidad o estructura distintiva de motores ajenos sin una licencia expresa y compatible.
- Tratar los materiales de terceros solo como entradas autorizadas por el usuario o como referencias funcionales abstractas.
- Registrar cada fuente curricular con título, URL oficial, ámbito y fecha de consulta.
- No presentar una norma, competencia o criterio como verificado si no se ha comprobado en la fuente oficial vigente.
- Leer [la política de fuentes](references/politica-fuentes-curriculares.md) cuando haya que recopilar o validar currículo.

## Flujo obligatorio

### 1. Abrir o reanudar el proyecto

Si existe un proyecto, ejecutar:

```bash
python3 scripts/coursekit.py status --project <ruta>
python3 scripts/coursekit.py validate --project <ruta>
```

Si es nuevo, recopilar lo imprescindible y crear la configuración con el esquema de [contrato del curso](references/contrato-curso.md). No generar unidades todavía.

### 2. Verificar el currículo

Usar fuentes oficiales estatales y de Andalucía aplicables a la etapa y al curso académico. Distinguir:

- texto literal o código oficial;
- paráfrasis pedagógica;
- decisión de diseño del docente;
- propuesta generada.

Cuando una norma no pueda confirmarse, marcarla como `pendiente`, explicar la limitación y no inventar elementos curriculares. FP requiere además la norma específica del título y del módulo.

Si existe un paquete curricular verificado, comprobarlo y cargarlo antes de diseñar:

```bash
python3 scripts/validate_curriculum_pack.py <paquete.json>
python3 scripts/coursekit.py load-pack --project <ruta> --pack <paquete.json>
```

Los paquetes disponibles se encuentran bajo `references/curriculos/` y deben leerse solo cuando coincidan territorio, etapa, nivel y materia.

### 3. Aprobar el mapa anual

Presentar antes de producir materiales una tabla compacta con:

| Secuencia | Periodo | Aprendizaje central | Producto o desempeño | Criterios | Sesiones |
|---|---|---|---|---|---|

Comprobar cobertura, progresión, carga temporal, evaluación y necesidades del grupo. Esperar aprobación del usuario si cambiar el mapa obligaría a rehacer materiales.

Exportar el mapa para revisión:

```bash
python3 scripts/coursekit.py export-map --project <ruta>
```

### 4. Crear un piloto completo

Generar una sola secuencia representativa con todos sus componentes:

- guía docente;
- material del alumnado;
- tareas y apoyos;
- evaluación e instrumentos;
- alternativas de acceso, participación y expresión;
- recursos digitales solo cuando aporten valor;
- trazabilidad entre actividad, evidencia y criterio.

Verificar el piloto contra [los criterios de aceptación](references/criterios-aceptacion.md). Pedir una única revisión conjunta antes de escalar el estilo y la estructura al curso entero.

Organizar la entrega con la doble capa descrita en [presentación visual](references/presentacion-entrega.md): originales canónicos para conservar trazabilidad y una vista docente atractiva con índice, carpetas numeradas, iconos acompañados de texto y nombres comprensibles. No imitar la identidad visual ni las plantillas distintivas de una referencia externa.

Cuando el entorno admita los generadores incluidos, crear los formatos editables antes de presentar la vista docente:

```bash
python3 scripts/build_polished_docs.py --project <ruta> --sequence <SEQ-XX>
NODE_PATH=<node_modules> node scripts/build_assessment_workbook.cjs --project <ruta> --sequence <SEQ-XX>
```

Abrir y revisar visualmente los DOCX y todas las hojas del XLSX. Si las dependencias no están disponibles, conservar los originales Markdown/CSV y marcar los formatos derivados como pendientes; no simular su creación.

### 5. Producir por bloques

Tras aprobar el piloto, producir bloques manejables y comprobarlos antes de continuar. Actualizar siempre el estado del proyecto. No afirmar que un archivo existe si no se ha creado y abierto o validado.

### 6. Validar y entregar

Ejecutar:

```bash
python3 scripts/coursekit.py validate --project <ruta> --strict
python3 scripts/coursekit.py present --project <ruta>
python3 scripts/coursekit.py manifest --project <ruta>
```

La entrega debe incluir el informe de validación, el inventario, las fuentes curriculares y una lista breve de elementos pendientes. No ocultar advertencias.

## Estructura propia del paquete

Usar esta organización salvo que la especificación aprobada exija otra:

```text
curso/
├── 00_control/
├── 10_diseno_anual/
├── 20_secuencias/
├── 30_recursos_comunes/
└── 90_entrega/
```

El detalle y los archivos mínimos están en [el contrato del curso](references/contrato-curso.md). Esta nomenclatura es interna a PromptDocentes y puede evolucionar mediante una versión de esquema.

## Límites

- No sustituir la revisión profesional del docente ni afirmar conformidad con inspección.
- No incluir datos personales de alumnado en configuraciones, ejemplos o paquetes.
- No incrustar claves, credenciales ni archivos con restricciones de redistribución.
- No publicar el paquete, la skill o sus fuentes sin confirmar la licencia de cada dependencia y recurso incorporado.
- Para un recurso individual, usar la skill `promptdocentes-recursos`.
