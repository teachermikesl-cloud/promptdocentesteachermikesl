#!/usr/bin/env node

const fs = require("node:fs");
const path = require("node:path");
const { Workbook, SpreadsheetFile } = require("@oai/artifact-tool");

const NAVY = "#38527D";
const BLUE = "#2B7BBB";
const PALE = "#F2F5FA";
const LIGHT_BLUE = "#EAF2FA";
const LIGHT_AMBER = "#FFF5D6";
const LIGHT_RED = "#FCE8E6";
const BORDER = "#D7DDE7";
const TEXT = "#263A59";
const FONT = "Aptos";

function arg(name) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

function baseSheet(sheet, color) {
  sheet.showGridLines = false;
  sheet.tabColor = color;
}

function title(sheet, range, value, context) {
  sheet.mergeCells(range);
  const start = range.split(":")[0];
  sheet.getRange(start).values = [[value]];
  sheet.getRange(range).format = {
    font: { name: FONT, size: 15, bold: true, color: TEXT },
    verticalAlignment: "center",
  };
  sheet.getRange(range).format.rowHeight = 28;
  const endColumn = range.match(/:([A-Z]+)/)[1];
  sheet.mergeCells(`A3:${endColumn}3`);
  sheet.getRange("A3").values = [[context]];
  sheet.getRange(`A3:${endColumn}3`).format = {
    font: { name: FONT, size: 10, italic: true, color: TEXT },
    verticalAlignment: "center",
  };
  sheet.getRange(`A3:${endColumn}3`).format.rowHeight = 24;
  sheet.getRange(`A4:${endColumn}4`).format.borders = { bottom: { style: "thin", color: NAVY } };
}

function header(range) {
  range.format = {
    fill: NAVY,
    font: { name: FONT, size: 10, bold: true, color: "#FFFFFF" },
    wrapText: true,
    verticalAlignment: "center",
    horizontalAlignment: "center",
    borders: { preset: "all", style: "thin", color: BORDER },
  };
}

function body(range) {
  range.format = {
    font: { name: FONT, size: 10, color: TEXT },
    wrapText: true,
    verticalAlignment: "center",
    borders: { preset: "all", style: "thin", color: BORDER },
  };
}

function shadeAlternate(sheet, start, end, lastColumn) {
  for (let row = start; row <= end; row += 1) {
    if (row % 2 === 0) sheet.getRange(`A${row}:${lastColumn}${row}`).format.fill = PALE;
  }
}

async function main() {
  const project = arg("--project");
  const previewDir = arg("--preview-dir");
  if (!project) throw new Error("Falta --project");
  const outputDir = path.join(path.resolve(project), "80_beta_privada");
  fs.mkdirSync(outputDir, { recursive: true });
  if (previewDir) fs.mkdirSync(previewDir, { recursive: true });

  const workbook = Workbook.create();
  const summary = workbook.worksheets.add("Resumen");
  const responses = workbook.worksheets.add("Respuestas");
  const issues = workbook.worksheets.add("Incidencias");
  baseSheet(summary, NAVY);
  baseSheet(responses, BLUE);
  baseSheet(issues, "#C67C00");

  title(summary, "A2:H2", "Seguimiento de la beta privada de PromptDocentes", "Curso piloto de Educación Física de 1.º ESO. Use códigos anónimos y no registre datos del alumnado.");
  summary.getRange("A6:B6").values = [["Indicador", "Resultado"]];
  header(summary.getRange("A6:B6"));
  summary.getRange("A7:A13").values = [
    ["Participantes registrados"],
    ["Claridad de navegación"],
    ["Utilidad docente"],
    ["Facilidad de edición"],
    ["Confianza para utilizarlo"],
    ["Incidencias abiertas"],
    ["Incidencias críticas abiertas"],
  ];
  summary.getRange("B7:B13").formulas = [
    ["=COUNTIF(Respuestas!A6:A35,\"<>\")"],
    ["=IF(B7=0,\"\",AVERAGE(Respuestas!K6:K35))"],
    ["=IF(B7=0,\"\",AVERAGE(Respuestas!L6:L35))"],
    ["=IF(B7=0,\"\",AVERAGE(Respuestas!M6:M35))"],
    ["=IF(B7=0,\"\",AVERAGE(Respuestas!N6:N35))"],
    ["=COUNTIF(Incidencias!I6:I105,\"<>Cerrada\")-COUNTBLANK(Incidencias!I6:I105)"],
    ["=COUNTIFS(Incidencias!D6:D105,\"Crítica\",Incidencias!I6:I105,\"<>Cerrada\")"],
  ];
  body(summary.getRange("A7:B13"));
  summary.getRange("B8:B11").format.numberFormat = "0.0";
  summary.getRange("B7:B13").format.horizontalAlignment = "center";
  summary.getRange("D6:H6").values = [["Criterio de paso", "Objetivo", "Resultado", "Estado", "Decisión"]];
  header(summary.getRange("D6:H6"));
  summary.getRange("D7:E11").values = [
    ["Tareas completadas sin ayuda", "80% o más"],
    ["Claridad de navegación", "4,0 o más"],
    ["Utilidad docente", "4,0 o más"],
    ["Facilidad de edición", "4,0 o más"],
    ["Incidencias críticas abiertas", "0"],
  ];
  summary.getRange("F7:F11").formulas = [
    ["=IF(B7=0,\"\",SUM(Respuestas!J6:J35)/(B7*8))"],
    ["=IF(B7=0,\"\",B8)"],
    ["=IF(B7=0,\"\",B9)"],
    ["=IF(B7=0,\"\",B10)"],
    ["=B13"],
  ];
  summary.getRange("G7:G11").formulas = [
    ["=IF(F7=\"\",\"Pendiente\",IF(F7>=0.8,\"Cumple\",\"Revisar\"))"],
    ["=IF(F8=\"\",\"Pendiente\",IF(F8>=4,\"Cumple\",\"Revisar\"))"],
    ["=IF(F9=\"\",\"Pendiente\",IF(F9>=4,\"Cumple\",\"Revisar\"))"],
    ["=IF(F10=\"\",\"Pendiente\",IF(F10>=4,\"Cumple\",\"Revisar\"))"],
    ["=IF(B7=0,\"Pendiente\",IF(F11=0,\"Cumple\",\"Bloqueada\"))"],
  ];
  summary.getRange("H7:H11").values = [
    ["Observar si las carpetas y etiquetas necesitan simplificación."],
    ["Revisar nombres, panel e instrucciones iniciales."],
    ["Priorizar cambios repetidos por varios docentes."],
    ["Comprobar compatibilidad de DOCX y XLSX."],
    ["Resolver antes de ampliar la beta."],
  ];
  body(summary.getRange("D7:H11"));
  summary.getRange("F7").format.numberFormat = "0%";
  summary.getRange("F8:F10").format.numberFormat = "0.0";
  summary.getRange("F7:G11").format.horizontalAlignment = "center";
  summary.getRange("G7:G11").conditionalFormats.add("containsText", { text: "Cumple", format: { fill: "#E8F5F0", font: { color: "#0B6B57", bold: true } } });
  summary.getRange("G7:G11").conditionalFormats.add("containsText", { text: "Revisar", format: { fill: LIGHT_AMBER, font: { color: "#7A5A00", bold: true } } });
  summary.getRange("G7:G11").conditionalFormats.add("containsText", { text: "Bloqueada", format: { fill: LIGHT_RED, font: { color: "#8A2F27", bold: true } } });
  summary.getRange("G7:G11").conditionalFormats.add("containsText", { text: "Pendiente", format: { fill: PALE, font: { color: TEXT } } });
  summary.getRange("A16:H16").merge();
  summary.getRange("A16").values = [["Decisión recomendada"]];
  summary.getRange("A16:H16").format = { fill: LIGHT_BLUE, font: { name: FONT, size: 11, bold: true, color: NAVY }, verticalAlignment: "center" };
  summary.getRange("A17:H18").merge();
  summary.getRange("A17").formulas = [["=IF(B7=0,\"Recoger respuestas antes de decidir.\",IF(B13>0,\"Resolver las incidencias críticas antes de ampliar la beta.\",IF(COUNTIF(G7:G11,\"Revisar\")>0,\"Aplicar mejoras y repetir una prueba breve.\",\"Preparar una beta más amplia y conservar el registro de cambios.\")))"]];
  summary.getRange("A17:H18").format = { font: { name: FONT, size: 11, color: TEXT }, wrapText: true, verticalAlignment: "center", borders: { preset: "outside", style: "thin", color: BORDER } };
  summary.getRange("A2:H18").format.font.name = FONT;
  summary.getRange("A:A").format.columnWidth = 31;
  summary.getRange("B:B").format.columnWidth = 16;
  summary.getRange("C:C").format.columnWidth = 3;
  summary.getRange("D:D").format.columnWidth = 26;
  summary.getRange("E:E").format.columnWidth = 14;
  summary.getRange("F:F").format.columnWidth = 13;
  summary.getRange("G:G").format.columnWidth = 14;
  summary.getRange("H:H").format.columnWidth = 36;

  title(responses, "A2:Q2", "Respuestas de participantes", "Una fila por docente. No introduzca nombres, correos ni datos identificativos del alumnado o del centro.");
  const responseHeaders = ["Código", "Fecha", "Etapa", "Materia o función", "Dispositivo", "Navegador", "Recorrido", "Secuencia 1", "Secuencia 2", "Tareas sin ayuda", "Navegación 1-5", "Utilidad 1-5", "Edición 1-5", "Confianza 1-5", "Mejora prioritaria", "Recomendación", "Observaciones"];
  responses.getRange("A5:Q5").values = [responseHeaders];
  header(responses.getRange("A5:Q5"));
  body(responses.getRange("A6:Q35"));
  shadeAlternate(responses, 6, 35, "Q");
  responses.getRange("B6:B35").format.numberFormat = "dd/mm/yyyy";
  responses.getRange("G6:G35").dataValidation = { rule: { type: "list", values: ["Rápido", "Completo", "Aplicación docente"] } };
  responses.getRange("H6:I35").dataValidation = { rule: { type: "list", values: ["SEQ-01", "SEQ-02", "SEQ-03", "SEQ-04", "SEQ-05", "SEQ-06", "SEQ-07", "SEQ-08", "SEQ-09", "SEQ-10", "No revisada"] } };
  responses.getRange("J6:J35").dataValidation = { rule: { type: "whole", operator: "between", formula1: 0, formula2: 8 } };
  responses.getRange("K6:N35").dataValidation = { rule: { type: "whole", operator: "between", formula1: 1, formula2: 5 } };
  responses.getRange("P6:P35").dataValidation = { rule: { type: "list", values: ["Ampliar beta", "Cambios menores", "Cambios importantes", "No recomendar todavía"] } };
  responses.freezePanes.freezeRows(5);
  const responseWidths = [12, 12, 20, 22, 20, 16, 18, 12, 12, 14, 14, 14, 14, 14, 30, 22, 38];
  responseWidths.forEach((width, index) => responses.getRange(`${String.fromCharCode(65 + index)}:${String.fromCharCode(65 + index)}`).format.columnWidth = width);
  responses.getRange("A5:Q35").format.rowHeight = 34;
  responses.getRange("A5:Q5").format.rowHeight = 42;

  title(issues, "A2:K2", "Registro de incidencias", "Una fila por problema. Describa pasos reproducibles y no incluya información personal.");
  const issueHeaders = ["ID", "Fecha", "Código participante", "Nivel", "Área", "Secuencia", "Archivo o ubicación", "Descripción y pasos", "Estado", "Decisión", "Responsable"];
  issues.getRange("A5:K5").values = [issueHeaders];
  header(issues.getRange("A5:K5"));
  body(issues.getRange("A6:K105"));
  shadeAlternate(issues, 6, 105, "K");
  issues.getRange("B6:B105").format.numberFormat = "dd/mm/yyyy";
  issues.getRange("D6:D105").dataValidation = { rule: { type: "list", values: ["Crítica", "Alta", "Media", "Baja"] } };
  issues.getRange("E6:E105").dataValidation = { rule: { type: "list", values: ["Acceso", "Navegación", "Contenido", "Currículo", "DOCX", "XLSX", "Accesibilidad", "Privacidad", "Seguridad", "Otro"] } };
  issues.getRange("F6:F105").dataValidation = { rule: { type: "list", values: ["General", "SEQ-01", "SEQ-02", "SEQ-03", "SEQ-04", "SEQ-05", "SEQ-06", "SEQ-07", "SEQ-08", "SEQ-09", "SEQ-10"] } };
  issues.getRange("I6:I105").dataValidation = { rule: { type: "list", values: ["Nueva", "Confirmada", "En corrección", "Pendiente de decisión", "Cerrada"] } };
  issues.getRange("J6:J105").dataValidation = { rule: { type: "list", values: ["Corregir", "Aplazar", "Descartar", "Investigar"] } };
  issues.getRange("D6:D105").conditionalFormats.add("containsText", { text: "Crítica", format: { fill: LIGHT_RED, font: { color: "#8A2F27", bold: true } } });
  issues.getRange("D6:D105").conditionalFormats.add("containsText", { text: "Alta", format: { fill: LIGHT_AMBER, font: { color: "#7A5A00", bold: true } } });
  issues.getRange("I6:I105").conditionalFormats.add("containsText", { text: "Cerrada", format: { fill: "#E8F5F0", font: { color: "#0B6B57" } } });
  issues.freezePanes.freezeRows(5);
  const issueWidths = [10, 12, 16, 12, 16, 12, 28, 48, 20, 16, 18];
  issueWidths.forEach((width, index) => issues.getRange(`${String.fromCharCode(65 + index)}:${String.fromCharCode(65 + index)}`).format.columnWidth = width);
  issues.getRange("A5:K105").format.rowHeight = 36;
  issues.getRange("A5:K5").format.rowHeight = 42;

  workbook.recalculate();
  const summaryInspect = await workbook.inspect({ kind: "table", range: "Resumen!A2:H18", include: "values,formulas", tableMaxRows: 20, tableMaxCols: 10, maxChars: 12000 });
  const errorInspect = await workbook.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!", options: { useRegex: true, maxResults: 100 }, summary: "final formula error scan", maxChars: 5000 });
  if (previewDir) {
    for (const [sheetName, fileName] of [["Resumen", "resumen.png"], ["Respuestas", "respuestas.png"], ["Incidencias", "incidencias.png"]]) {
      const preview = await workbook.render({ sheetName, autoCrop: "all", scale: 1, format: "png" });
      fs.writeFileSync(path.join(previewDir, fileName), new Uint8Array(await preview.arrayBuffer()));
    }
    fs.writeFileSync(path.join(previewDir, "inspect.ndjson"), `${summaryInspect.ndjson}\n${errorInspect.ndjson}\n`);
  }
  const output = await SpreadsheetFile.exportXlsx(workbook);
  await output.save(path.join(outputDir, "registro-beta-privada.xlsx"));
  console.log(`Registro beta creado en ${outputDir}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
