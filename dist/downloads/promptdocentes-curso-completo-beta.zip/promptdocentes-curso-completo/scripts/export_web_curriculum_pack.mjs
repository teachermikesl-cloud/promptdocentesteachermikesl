#!/usr/bin/env node

/**
 * Convierte una selección de la biblioteca curricular de PromptDocentes en un
 * paquete consumible por la skill de curso completo. Esta primera versión
 * admite Educación Primaria y conserva explícitamente los límites de la fuente.
 */

import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";

function argument(name) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

function fail(message) {
  console.error(`ERROR: ${message}`);
  process.exit(2);
}

function isoDate(value) {
  const match = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value || "");
  return match ? `${match[3]}-${match[2]}-${match[1]}` : value;
}

function slug(value) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function splitDescriptors(text) {
  const match = /^(.*?)(?:\s+)((?:(?:CCL|CP|STEM|CD|CPSAA|CC|CE|CCEC)\d(?:,\s*)?)+)\.?$/.exec(text);
  if (!match) return { text, descriptors: [] };
  return {
    text: match[1].trim(),
    descriptors: match[2].split(",").map(item => item.trim()).filter(Boolean),
  };
}

const stage = argument("--stage") || "primary";
const subjectId = argument("--subject");
const grade = argument("--level");
const webRoot = path.resolve(argument("--web-root") || "../tizaprompt/dist");
const outputArg = argument("--output");

if (stage !== "primary") fail("esta versión admite únicamente --stage primary");
if (!subjectId) fail("falta --subject");
if (!grade || !/^[1-6]$/.test(grade)) fail("--level debe ser un curso de Primaria entre 1 y 6");

const sourcePath = path.join(webRoot, "data", "primary-curriculum.js");
if (!fs.existsSync(sourcePath)) fail(`no existe la biblioteca curricular: ${sourcePath}`);

const context = { window: {} };
vm.runInNewContext(fs.readFileSync(sourcePath, "utf8"), context, { filename: sourcePath });
const library = context.window.PRIMARY_CURRICULUM;
if (!library?.subjects) fail("la biblioteca de Primaria no tiene la estructura esperada");

const canonicalSubjectId = library.aliases?.[subjectId] || subjectId;
const subject = library.subjects[canonicalSubjectId];
if (!subject) fail(`materia desconocida: ${subjectId}. Opciones: ${Object.keys(library.subjects).join(", ")}`);

const cycle = grade <= 2 ? "1" : grade <= 4 ? "2" : "3";
const cycleData = subject.cycles?.[cycle];
const criteria = cycleData?.criteriaByGrade?.[grade];
if (!cycleData || !criteria) fail(`no hay datos para ${subject.title}, ${grade}.º de Primaria`);

const competencies = cycleData.competencies.map(item => {
  const parsed = splitDescriptors(item.text);
  return { id: `CE${item.code}`, text: parsed.text, descriptors: parsed.descriptors };
});

const evaluationCriteria = criteria.map(item => ({
  id: item.code,
  competency_id: `CE${item.code.split(".")[0]}`,
  text: item.text,
  core_learning_ids: [],
}));

const referenced = new Set(cycleData.saberReferences || []);
const coreLearning = Object.fromEntries(
  (cycleData.sabers || [])
    .filter(item => referenced.has(item.code) || [...referenced].some(code => code.startsWith(`${item.code}.`)))
    .map(item => [item.code, item.text])
);

const checkedOn = isoDate(library.source.verifiedOn);
const packId = `andalucia-primaria-${slug(subject.title)}-${grade}`;
const pack = {
  schema_version: "1.0",
  pack_id: packId,
  title: `${subject.title} · ${grade}.º de Primaria · Andalucía`,
  context: {
    territory: "Andalucía",
    stage: "Educación Primaria",
    level: `${grade}.º de Primaria`,
    subject: subject.title,
  },
  verified_on: checkedOn,
  content_status: {
    competencies: "Transcripción estructurada de la biblioteca curricular de PromptDocentes a partir del PDF oficial firmado.",
    evaluation_criteria: "Transcripción estructurada por curso de la biblioteca curricular de PromptDocentes.",
    core_learning: "Saberes del ciclo correspondiente; no se atribuye una relación oficial criterio–saber cuando la fuente estructurada no la incorpora.",
  },
  verification: {
    status: "verified_source_transcription",
    method: "Conversión determinista de la biblioteca curricular ya extraída del PDF oficial firmado y validación estructural del paquete.",
    signed_pdf_pages: cycleData.officialPdfPages || [],
    cve: library.source.cve,
    note: "Este paquete conserva la transcripción disponible, pero no certifica la integración de modificaciones posteriores ni relaciones criterio–saber no presentes en la biblioteca. La vigencia consolidada debe revisarse antes de uso institucional.",
  },
  sources: [
    {
      id: "SRC-001",
      title: library.source.title,
      url: library.source.url,
      issuer: "Junta de Andalucía · BOJA",
      scope: `${library.source.annex} · ${subject.title} · ${cycle}.º ciclo de Primaria`,
      status: "verified",
      checked_on: checkedOn,
    },
  ],
  competencies,
  evaluation_criteria: evaluationCriteria,
  core_learning: coreLearning,
  pending_checks: [
    "Contrastar la vigencia consolidada de la normativa antes de presentar el paquete como actualizado.",
    "Verificar o justificar pedagógicamente las relaciones criterio–saber; este paquete no las atribuye como oficiales.",
  ],
};

const output = path.resolve(outputArg || path.join("references", "curriculos", "andalucia", `${slug(subject.title)}-${grade}primaria.json`));
fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, `${JSON.stringify(pack, null, 2)}\n`, "utf8");
console.log(`Paquete creado: ${output}`);
console.log(`Competencias: ${competencies.length} · criterios: ${evaluationCriteria.length} · saberes: ${Object.keys(coreLearning).length}`);

