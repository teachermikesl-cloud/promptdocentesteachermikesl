#!/usr/bin/env python3
"""Convierte los originales Markdown de una secuencia en DOCX editables y coherentes."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

NAVY = "344A72"
PALE = "F7F8FC"
GRAY = "5D6B80"
BORDER = "D9D9D9"
FONT = "Arial"

THEMES = {
    "guide": {"accent": "305B8C", "pale": "EAF1F8", "label": "PLANIFICACIÓN DOCENTE", "icon": "📘"},
    "session": {"accent": "087F8C", "pale": "E4F3F4", "label": "GUÍA DE APLICACIÓN", "icon": "🧭"},
    "student": {"accent": "1479B8", "pale": "E8F4FB", "label": "CUADERNO DE TRABAJO", "icon": "✏️"},
    "assessment": {"accent": "9C365C", "pale": "F8EAF0", "label": "EVALUACIÓN", "icon": "🎯"},
    "cards": {"accent": "B76B16", "pale": "FFF3E2", "label": "RECURSOS PARA LA PRÁCTICA", "icon": "🎲"},
    "support": {"accent": "257A5A", "pale": "E8F5EF", "label": "REFUERZO Y ANDAMIAJE", "icon": "🛟"},
    "extension": {"accent": "6C4AA0", "pale": "F1ECF8", "label": "AMPLIACIÓN", "icon": "🚀"},
    "access": {"accent": "604A8B", "pale": "F0EDF7", "label": "ACCESIBILIDAD", "icon": "🧩"},
}


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=110, start=120, bottom=110, end=120) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    margins = tc_pr.first_child_found_in("w:tcMar")
    if margins is None:
        margins = OxmlElement("w:tcMar")
        tc_pr.append(margins)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = margins.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            margins.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table) -> None:
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = borders.find(qn(f"w:{edge}"))
        if tag is None:
            tag = OxmlElement(f"w:{edge}")
            borders.append(tag)
        tag.set(qn("w:val"), "single")
        tag.set(qn("w:sz"), "4")
        tag.set(qn("w:color"), BORDER)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    header = OxmlElement("w:tblHeader")
    header.set(qn("w:val"), "true")
    tr_pr.append(header)


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    cant_split.set(qn("w:val"), "true")
    tr_pr.append(cant_split)


def add_inline(paragraph, text: str) -> None:
    parts = re.split(r"(\*\*.*?\*\*|`.*?`)", text)
    for part in parts:
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            run.bold = True
        elif part.startswith("`") and part.endswith("`"):
            run = paragraph.add_run(part[1:-1])
            run.font.name = "Courier New"
            run.font.size = Pt(9)
        else:
            paragraph.add_run(part)


def clean_heading(text: str) -> str:
    text = re.sub(r"^\d+(?:\.\d+)*[.·]?\s*", "", text.strip())
    return text.replace(" · ", " ").strip(" .:–—-")


def configure_document(doc: Document, short_title: str, theme: dict, landscape: bool = False) -> None:
    section = doc.sections[0]
    if landscape:
        section.orientation = WD_ORIENT.LANDSCAPE
        section.page_width, section.page_height = section.page_height, section.page_width
    section.top_margin = Cm(2)
    section.bottom_margin = Cm(1.8)
    section.left_margin = Cm(2.1)
    section.right_margin = Cm(2.1)

    normal = doc.styles["Normal"]
    normal.font.name = FONT
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = RGBColor(32, 48, 74)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.12

    for style_name, size, before, after in (
        ("Title", 28, 0, 12),
        ("Heading 1", 17, 15, 7),
        ("Heading 2", 13, 12, 5),
        ("Heading 3", 11, 9, 4),
    ):
        style = doc.styles[style_name]
        style.font.name = FONT
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True
    title_ppr = doc.styles["Title"]._element.get_or_add_pPr()
    title_border = title_ppr.find(qn("w:pBdr"))
    if title_border is not None:
        title_ppr.remove(title_border)

    header = section.header.paragraphs[0]
    header.text = f"PROMPTDOCENTES   ·   {theme['label']}"
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for run in header.runs:
        run.font.name = FONT
        run.font.size = Pt(8)
        run.font.bold = True
        run.font.color.rgb = RGBColor.from_string(theme["accent"])

    footer = section.footer.paragraphs[0]
    footer.text = short_title
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in footer.runs:
        run.font.name = FONT
        run.font.size = Pt(8)
        run.font.color.rgb = RGBColor(93, 107, 128)


def add_cover(doc: Document, title: str, category: str, config: dict, sequence: dict, theme: dict) -> None:
    band = doc.add_table(rows=1, cols=1)
    band.alignment = WD_TABLE_ALIGNMENT.CENTER
    band.autofit = False
    band.columns[0].width = Cm(16.4)
    set_cell_shading(band.cell(0, 0), theme["accent"])
    set_cell_margins(band.cell(0, 0), top=150, bottom=150)
    set_repeat_table_header(band.rows[0])
    band_text = band.cell(0, 0).paragraphs[0]
    band_text.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = band_text.add_run(theme["label"])
    run.bold = True
    run.font.name = FONT
    run.font.size = Pt(11)
    run.font.color.rgb = RGBColor(255, 255, 255)
    doc.add_paragraph()
    p = doc.add_paragraph(style="Title")
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.add_run(title)
    subtitle = doc.add_paragraph()
    subtitle.add_run(category).bold = True
    subtitle.runs[0].font.color.rgb = RGBColor.from_string(theme["accent"])
    meta = doc.add_table(rows=2, cols=2)
    meta.alignment = WD_TABLE_ALIGNMENT.LEFT
    set_table_borders(meta)
    values = (
        ("ETAPA Y CURSO", f"{config['context']['stage']} · {config['context']['level']}"),
        ("MATERIA Y DURACIÓN", f"{config['context']['subject']} · {sequence['sessions']} sesiones"),
    )
    for row, (label, value) in zip(meta.rows, values):
        set_cell_shading(row.cells[0], theme["pale"])
        set_cell_margins(row.cells[0]); set_cell_margins(row.cells[1])
        row.cells[0].text = label
        row.cells[1].text = value
        row.cells[0].paragraphs[0].runs[0].bold = True
        row.cells[0].paragraphs[0].runs[0].font.color.rgb = RGBColor.from_string(theme["accent"])
    set_repeat_table_header(meta.rows[0])
    doc.add_paragraph()
    doc.add_paragraph(sequence["central_learning"])
    doc.add_paragraph("Documento editable del piloto. Revise espacio, material, duración real y necesidades de acceso antes de aplicarlo.")
    doc.add_paragraph("PromptDocentes · Teacher MikeSL")
    doc.add_page_break()


def add_table(doc: Document, rows: list[list[str]], theme: dict) -> None:
    if len(rows) < 2:
        return
    cols = max(len(row) for row in rows)
    table = doc.add_table(rows=0, cols=cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    set_table_borders(table)
    for row_index, values in enumerate(rows):
        cells = table.add_row().cells
        for col_index in range(cols):
            value = values[col_index].strip() if col_index < len(values) else ""
            cells[col_index].text = ""
            add_inline(cells[col_index].paragraphs[0], value)
            cells[col_index].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cells[col_index])
            if row_index == 0:
                set_cell_shading(cells[col_index], theme["accent"])
                for run in cells[col_index].paragraphs[0].runs:
                    run.font.color.rgb = RGBColor(255, 255, 255)
                    run.font.bold = True
            elif row_index % 2 == 0:
                set_cell_shading(cells[col_index], theme["pale"])
        if row_index == 0:
            set_repeat_table_header(table.rows[0])
        prevent_row_split(table.rows[row_index])
    doc.add_paragraph()


def markdown_to_doc(doc: Document, text: str, theme: dict, skip_first_title: bool = True, page_break_prefixes: tuple[str, ...] = ()) -> None:
    lines = text.splitlines()
    i = 0
    first_h1_skipped = False
    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        if not stripped:
            i += 1
            continue
        if stripped.startswith("|") and stripped.endswith("|"):
            block = []
            while i < len(lines) and lines[i].strip().startswith("|") and lines[i].strip().endswith("|"):
                block.append([cell.strip() for cell in lines[i].strip().strip("|").split("|")])
                i += 1
            rows = [row for row in block if not all(re.fullmatch(r":?-{3,}:?", cell) for cell in row)]
            add_table(doc, rows, theme)
            continue
        heading = re.match(r"^(#{1,4})\s+(.+)$", stripped)
        if heading:
            level = len(heading.group(1))
            heading_text = clean_heading(heading.group(2))
            if level == 1 and skip_first_title and not first_h1_skipped:
                first_h1_skipped = True
            else:
                if any(heading_text.startswith(prefix) for prefix in page_break_prefixes):
                    doc.add_page_break()
                style = "Heading 1" if level <= 2 else "Heading 2" if level == 3 else "Heading 3"
                doc.add_paragraph(heading_text, style=style)
            i += 1
            continue
        if stripped.startswith("- [ ]") or stripped.startswith("- [x]"):
            paragraph = doc.add_paragraph()
            paragraph.paragraph_format.left_indent = Cm(0.5)
            paragraph.paragraph_format.first_line_indent = Cm(-0.5)
            add_inline(paragraph, ("☐ " if stripped.startswith("- [ ]") else "☑ ") + stripped[5:].strip())
        elif stripped.startswith("- "):
            # Use an explicit hanging bullet instead of Word's inherited List Bullet
            # numbering. LibreOffice can otherwise move a following bullet to the end
            # of the previous line when the document is rendered or exported.
            paragraph = doc.add_paragraph()
            paragraph.paragraph_format.left_indent = Cm(0.7)
            paragraph.paragraph_format.first_line_indent = Cm(-0.45)
            bullet = paragraph.add_run("•  ")
            bullet.bold = True
            bullet.font.color.rgb = RGBColor.from_string(theme["accent"])
            add_inline(paragraph, stripped[2:].strip())
        elif re.match(r"^\d+\.\s+", stripped):
            match = re.match(r"^(\d+)\.\s+(.+)$", stripped)
            paragraph = doc.add_paragraph()
            paragraph.paragraph_format.left_indent = Cm(0.7)
            paragraph.paragraph_format.first_line_indent = Cm(-0.7)
            paragraph.add_run(f"{match.group(1)}.  ")
            add_inline(paragraph, match.group(2))
        else:
            paragraph = doc.add_paragraph()
            add_inline(paragraph, stripped.replace("  ", " "))
        i += 1


def build_document(output: Path, title: str, category: str, config: dict, sequence: dict, sources: list[Path], theme_name: str, page_break_prefixes: tuple[str, ...] = (), landscape: bool = False) -> None:
    doc = Document()
    theme = THEMES[theme_name]
    configure_document(doc, title, theme, landscape)
    add_cover(doc, title, category, config, sequence, theme)
    for index, source in enumerate(sources):
        if index:
            doc.add_section(WD_SECTION.NEW_PAGE)
            source_title = next((line[2:].strip() for line in source.read_text(encoding="utf-8").splitlines() if line.startswith("# ")), source.stem)
            doc.add_paragraph(clean_heading(source_title), style="Heading 1")
        markdown_to_doc(doc, source.read_text(encoding="utf-8"), theme, page_break_prefixes=page_break_prefixes)
    core = doc.core_properties
    core.title = title
    core.subject = f"{config['context']['subject']} {config['context']['level']}"
    core.author = "Teacher MikeSL"
    core.keywords = "PromptDocentes, educación, secuencia didáctica"
    output.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--sequence", required=True)
    args = parser.parse_args()
    project = args.project.resolve()
    config = json.loads((project / "00_control" / "curso.json").read_text(encoding="utf-8"))
    sequence = next(item for item in config["sequence_map"] if item["id"] == args.sequence)
    source = project / "20_secuencias" / args.sequence
    output = source / "documentos-editables"
    cards_source = source / "recursos" / "tarjetas-retos.md"
    cards_title = next(
        (
            clean_heading(line[2:].strip())
            for line in cards_source.read_text(encoding="utf-8").splitlines()
            if line.startswith("# ")
        ),
        "Tarjetas para la práctica",
    )
    specs = [
        ("guia-docente.docx", sequence["title"], "Guía docente completa", [source / "guia-docente.md"], "guide", ("Secuencia de sesiones", "Sesión 2", "Sesión 3", "Sesión 4", "Sesión 5", "Sesión 6", "Sesión 7", "Sesión 8", "Sesión 9"), False),
        ("guia-paso-a-paso.docx", "Aplicación sesión a sesión", "Guía práctica para pista o aula", [source / "recursos" / "guia-paso-a-paso.md"], "session", ("Sesión ",), False),
        ("material-alumnado.docx", sequence["title"], "Material del alumnado", [source / "material-alumnado.md"], "student", (), False),
        ("tarjetas-retos.docx", cards_title, "Tarjetas para la práctica", [cards_source], "cards", ("Tarjeta B", "Tarjeta C", "Tarjeta D", "Tarjeta E", "Tarjeta F"), False),
        ("evaluacion-y-soluciones.docx", "Evaluación de la secuencia", "Instrumentos y orientaciones de corrección", [source / "recursos" / "instrumentos-evaluacion.md", source / "recursos" / "soluciones-y-criterios.md"], "assessment", (), True),
        ("refuerzo-apoyo.docx", "Refuerzo y apoyo", "Itinerarios graduados para progresar", [source / "recursos" / "refuerzo-apoyo.md"], "support", (), False),
        ("ampliacion-enriquecimiento.docx", "Ampliación y enriquecimiento", "Retos de profundización", [source / "recursos" / "ampliacion-enriquecimiento.md"], "extension", (), False),
        ("apoyos-accesibilidad.docx", "Apoyos y accesibilidad", "Barreras, ajustes y comprobación", [source / "recursos" / "apoyos-accesibilidad.md"], "access", (), False),
    ]
    for filename, title, category, inputs, theme_name, page_break_prefixes, landscape in specs:
        missing = [str(path) for path in inputs if not path.is_file()]
        if missing:
            raise FileNotFoundError("Faltan originales: " + ", ".join(missing))
        build_document(output / filename, title, category, config, sequence, inputs, theme_name, page_break_prefixes, landscape)
    print(f"Documentos creados en {output} ({len(specs)} DOCX)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
