from __future__ import annotations

import argparse
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


FONT = "Aptos"
NAVY = "38527D"
PALE = "EAF0F8"
LIGHT = "F5F7FA"
BORDER = "D9D9D9"
TEXT = "263A59"


def shade(cell, color: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), color)


def margins(cell, top=110, start=110, bottom=110, end=110) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for edge, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{edge}"))
        if node is None:
            node = OxmlElement(f"w:{edge}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def borders(table) -> None:
    tbl_pr = table._tbl.tblPr
    current = tbl_pr.find(qn("w:tblBorders"))
    if current is not None:
        tbl_pr.remove(current)
    node = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        item = OxmlElement(f"w:{edge}")
        item.set(qn("w:val"), "single")
        item.set(qn("w:sz"), "4")
        item.set(qn("w:color"), BORDER)
        node.append(item)
    tbl_pr.append(node)


def repeat_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tag = OxmlElement("w:tblHeader")
    tag.set(qn("w:val"), "true")
    tr_pr.append(tag)


def no_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tr_pr.append(OxmlElement("w:cantSplit"))


def configure(doc: Document, title: str) -> None:
    section = doc.sections[0]
    section.top_margin = Cm(1.7)
    section.bottom_margin = Cm(1.6)
    section.left_margin = Cm(2.0)
    section.right_margin = Cm(2.0)
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = FONT
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = RGBColor.from_string(TEXT)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.08
    for name, size, before, after in (
        ("Title", 26, 0, 14),
        ("Heading 1", 17, 15, 6),
        ("Heading 2", 13, 10, 4),
    ):
        style = styles[name]
        style.font.name = FONT
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True
    styles["Title"].paragraph_format.keep_with_next = True
    title_ppr = styles["Title"]._element.get_or_add_pPr()
    title_border = title_ppr.find(qn("w:pBdr"))
    if title_border is not None:
        title_ppr.remove(title_border)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run("PromptDocentes · Teacher MikeSL · Beta privada")
    run.font.name = FONT
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor(96, 111, 132)
    props = doc.core_properties
    props.title = title
    props.author = "Teacher MikeSL"
    props.subject = "Prueba beta privada de PromptDocentes"
    props.keywords = "PromptDocentes, beta privada, revisión docente"


def add_title(doc: Document, title: str, subtitle: str) -> None:
    title_paragraph = doc.add_paragraph(title, style="Title")
    title_paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p = doc.add_paragraph()
    r = p.add_run(subtitle)
    r.bold = True
    r.font.name = FONT
    r.font.size = Pt(12)
    r.font.color.rgb = RGBColor.from_string(NAVY)


def add_bullets(doc: Document, items: list[str], numbered: bool = False) -> None:
    if numbered:
        for index, item in enumerate(items, start=1):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.8)
            p.paragraph_format.first_line_indent = Cm(-0.8)
            p.add_run(f"{index}. ").bold = True
            p.add_run(item)
    else:
        for item in items:
            p = doc.add_paragraph(style="List Bullet")
            p.add_run(item)


def add_table(doc: Document, headers: list[str], rows: list[list[str]], widths: list[float] | None = None) -> None:
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False if widths else True
    borders(table)
    for index, value in enumerate(headers):
        cell = table.rows[0].cells[index]
        cell.text = value
        shade(cell, NAVY)
        margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for run in cell.paragraphs[0].runs:
            run.bold = True
            run.font.name = FONT
            run.font.color.rgb = RGBColor(255, 255, 255)
        if widths:
            cell.width = Cm(widths[index])
    repeat_header(table.rows[0])
    for row_index, values in enumerate(rows):
        cells = table.add_row().cells
        for column_index, value in enumerate(values):
            cells[column_index].text = value
            margins(cells[column_index])
            cells[column_index].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if row_index % 2:
                shade(cells[column_index], PALE)
            if widths:
                cells[column_index].width = Cm(widths[column_index])
        no_split(table.rows[-1])
    doc.add_paragraph()


def add_checklist(doc: Document, items: list[str]) -> None:
    for item in items:
        p = doc.add_paragraph()
        p.add_run("☐ ").bold = True
        p.add_run(item)


def build_guide(path: Path) -> None:
    doc = Document()
    configure(doc, "Guía para la prueba beta privada de PromptDocentes")
    add_title(doc, "Guía para la prueba beta privada de PromptDocentes", "Curso piloto de Educación Física de 1.º ESO")
    doc.add_paragraph(
        "Esta guía permite comprobar si el proyecto se entiende, se navega con facilidad y ofrece materiales que un docente puede adaptar. "
        "La prueba no evalúa al participante. Busca localizar decisiones confusas, documentos innecesarios, fallos técnicos y riesgos antes de ampliar el sistema a otras materias y etapas."
    )
    doc.add_paragraph("Autor del proyecto: Teacher MikeSL. Versión de prueba: septiembre de 2026.")

    doc.add_heading("Qué debe probarse", level=1)
    add_bullets(doc, [
        "Acceso al panel y localización de una secuencia concreta.",
        "Comprensión de la relación entre guía docente, material del alumnado, evaluación y apoyos.",
        "Apertura y edición de archivos DOCX y XLSX en un dispositivo habitual.",
        "Utilidad real de las actividades, instrucciones, instrumentos y alternativas de acceso.",
        "Claridad de las advertencias sobre privacidad, seguridad y revisión profesional.",
    ])

    doc.add_heading("Quién puede participar", level=1)
    doc.add_paragraph(
        "La primera ronda puede realizarse con entre tres y cinco docentes. Conviene incluir, si es posible, una persona de Educación Física, "
        "otra de una materia diferente y otra con experiencia en coordinación, atención a la diversidad o competencia digital. No hace falta que utilicen ChatGPT."
    )

    doc.add_heading("Recorridos de prueba", level=1)
    add_table(doc, ["Recorrido", "Duración", "Tareas"], [
        ["Rápido", "30 a 40 minutos", "Abrir el panel, localizar una secuencia, revisar cuatro documentos y registrar la impresión general."],
        ["Completo", "60 a 80 minutos", "Comparar dos secuencias, editar un documento y una hoja de cálculo, y registrar incidencias concretas."],
        ["Aplicación docente", "Una o más sesiones", "Revisar previamente en el centro, adaptar una actividad y recoger solo observaciones profesionales sin datos del alumnado."],
    ], [3.0, 3.2, 10.0])

    doc.add_page_break()
    doc.add_heading("Recorrido recomendado", level=1)
    add_bullets(doc, [
        "Abra el panel de navegación y localice SEQ-04 Cooperar para superar.",
        "Lea la guía docente y compruebe si entiende el propósito, las sesiones y las evidencias de aprendizaje.",
        "Abra el material del alumnado, la evaluación y los apoyos de accesibilidad.",
        "Cambie una consigna, una duración o una adaptación en una copia local del documento.",
        "Abra el registro de evaluación y compruebe los desplegables, la rúbrica y las fuentes curriculares.",
        "Repita la localización con SEQ-10 Entorno activo y sostenible para comprobar seguridad y sostenibilidad.",
        "Cumplimente el cuestionario individual y anote cada problema por separado en el registro consolidado.",
    ], numbered=True)

    doc.add_heading("Tareas observables", level=1)
    add_table(doc, ["Código", "Tarea", "Se considera completada cuando"], [
        ["T01", "Entrar por el panel", "La persona llega a una secuencia sin ayuda externa."],
        ["T02", "Localizar materiales", "Distingue guía, alumnado, evaluación, recursos y apoyos."],
        ["T03", "Comprender la secuencia", "Explica qué se aprende, qué se produce y cómo se evalúa."],
        ["T04", "Editar un DOCX", "Guarda un cambio en una copia y conserva la maquetación básica."],
        ["T05", "Usar el XLSX", "Introduce un código ficticio y selecciona valores de los desplegables."],
        ["T06", "Encontrar apoyos", "Localiza una alternativa que conserve la finalidad de la tarea."],
        ["T07", "Detectar límites", "Identifica la necesidad de adaptar el recurso al centro y al grupo."],
        ["T08", "Registrar una incidencia", "Describe el problema, el archivo y el resultado esperado."],
    ], [1.8, 5.4, 9.0])

    doc.add_heading("Qué información debe recogerse", level=1)
    add_bullets(doc, [
        "Código anónimo del participante, etapa, materia y experiencia digital aproximada.",
        "Dispositivo, sistema, navegador y programa usado para abrir los archivos.",
        "Tareas completadas sin ayuda, con ayuda o no completadas.",
        "Valoraciones del uno al cinco sobre navegación, claridad, utilidad, edición y confianza de uso.",
        "Incidencias reproducibles con pasos, resultado observado y resultado esperado.",
        "Sugerencias concretas de eliminación, cambio o incorporación.",
    ])

    doc.add_heading("Privacidad y condiciones de uso", level=1)
    add_bullets(doc, [
        "No registre nombres, correos, imágenes, ubicaciones, diagnósticos ni producciones identificables del alumnado.",
        "Use códigos ficticios en las hojas de cálculo de prueba.",
        "Trabaje con copias cuando vaya a modificar documentos.",
        "Revise cualquier actividad práctica según espacios, recursos, normas y protocolos reales del centro.",
        "No presente el material como normativa ni como aprobación institucional de la Junta de Andalucía.",
    ])

    doc.add_heading("Criterios para cerrar la beta", level=1)
    doc.add_paragraph("La recomendación inicial es considerar preparada la siguiente fase cuando se cumplan conjuntamente estas condiciones:")
    add_checklist(doc, [
        "Al menos el 80 por ciento de las tareas se completa sin ayuda.",
        "La media de claridad, utilidad y facilidad de edición alcanza cuatro sobre cinco.",
        "No queda abierta ninguna incidencia crítica de privacidad, seguridad, pérdida de archivos o acceso.",
        "Todos los documentos seleccionados se abren y editan en los dispositivos probados.",
        "Las observaciones repetidas disponen de una decisión documentada: corregir, aplazar o descartar.",
    ])

    doc.add_heading("Cómo clasificar una incidencia", level=1)
    add_table(doc, ["Nivel", "Definición", "Ejemplo"], [
        ["Crítica", "Impide usar el proyecto o crea un riesgo de privacidad o seguridad.", "El archivo no abre o pide datos personales."],
        ["Alta", "Bloquea una tarea importante sin alternativa clara.", "No se localiza la evaluación."],
        ["Media", "Dificulta el uso, pero tiene una solución provisional.", "Una tabla se desordena al abrirla."],
        ["Baja", "Mejora de redacción, diseño o comodidad sin bloqueo.", "Una etiqueta podría ser más breve."],
    ], [2.5, 7.2, 6.5])

    result = doc.add_paragraph()
    result.paragraph_format.space_before = Pt(5)
    result.paragraph_format.space_after = Pt(0)
    label = result.add_run("Resultado de la ronda. ")
    label.bold = True
    result.add_run(
        "Teacher MikeSL consolidará las respuestas, agrupará los problemas repetidos y priorizará las mejoras. "
        "La siguiente versión indicará qué se ha corregido, qué se mantiene y qué queda fuera del alcance de la beta."
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(path)


def add_scale(doc: Document, prompt: str) -> None:
    p = doc.add_paragraph()
    p.add_run(prompt).bold = True
    p.add_run("\n☐ 1      ☐ 2      ☐ 3      ☐ 4      ☐ 5")


def build_questionnaire(path: Path) -> None:
    doc = Document()
    configure(doc, "Cuestionario individual de la prueba beta de PromptDocentes")
    add_title(doc, "Cuestionario individual de la prueba beta de PromptDocentes", "Cumplimentación anónima para docentes participantes")
    doc.add_paragraph(
        "Use un código inventado y responda después de realizar uno de los recorridos de la guía. No incluya nombres, correos, datos del alumnado ni información sensible del centro."
    )

    doc.add_heading("Datos de la prueba", level=1)
    add_table(doc, ["Campo", "Respuesta"], [
        ["Código del participante", ""],
        ["Fecha", ""],
        ["Etapa o ámbito principal", ""],
        ["Materia o función", ""],
        ["Dispositivo y sistema", ""],
        ["Navegador", ""],
        ["Programa usado para DOCX y XLSX", ""],
        ["Recorrido realizado", "☐ Rápido   ☐ Completo   ☐ Aplicación docente"],
        ["Secuencias revisadas", ""],
    ], [6.0, 10.2])

    doc.add_heading("Realización de tareas", level=1)
    add_table(doc, ["Tarea", "Sin ayuda", "Con ayuda", "No completada", "Observación breve"], [
        ["Entrar por el panel", "☐", "☐", "☐", ""],
        ["Localizar una secuencia", "☐", "☐", "☐", ""],
        ["Distinguir los tipos de material", "☐", "☐", "☐", ""],
        ["Comprender propósito y evaluación", "☐", "☐", "☐", ""],
        ["Editar una copia DOCX", "☐", "☐", "☐", ""],
        ["Usar el registro XLSX", "☐", "☐", "☐", ""],
        ["Localizar apoyos de acceso", "☐", "☐", "☐", ""],
        ["Registrar una incidencia", "☐", "☐", "☐", ""],
    ], [5.0, 2.2, 2.2, 2.6, 4.2])

    doc.add_heading("Valoración", level=1)
    doc.add_paragraph("Marque una opción en cada afirmación. 1 significa muy difícil o poco útil y 5 significa muy fácil o muy útil.")
    for prompt in (
        "La navegación por las carpetas resulta clara.",
        "Los nombres e iconos ayudan a localizar cada documento.",
        "La guía docente explica cómo aplicar la secuencia.",
        "El material del alumnado se puede utilizar y adaptar.",
        "La evaluación se relaciona con lo que se enseña.",
        "Los apoyos conservan la finalidad de aprendizaje.",
        "Los archivos se abren y editan con facilidad.",
        "Las advertencias sobre privacidad y seguridad son suficientes.",
        "Utilizaría este tipo de proyecto en mi práctica docente.",
    ):
        add_scale(doc, prompt)

    doc.add_heading("Observaciones", level=1)
    prompts = [
        "Lo más útil del proyecto es",
        "Lo que más dificulta su uso es",
        "El documento que eliminaría o simplificaría es",
        "El documento o función que echo en falta es",
        "La primera mejora que realizaría es",
        "Otra materia o etapa en la que probaría el sistema es",
    ]
    for prompt in prompts:
        p = doc.add_paragraph()
        p.add_run(prompt).bold = True
        doc.add_paragraph("________________________________________________________________________________")
        doc.add_paragraph("________________________________________________________________________________")

    doc.add_heading("Incidencia principal", level=1)
    add_table(doc, ["Campo", "Descripción"], [
        ["Archivo o ubicación", ""],
        ["Pasos realizados", ""],
        ["Resultado observado", ""],
        ["Resultado esperado", ""],
        ["Frecuencia", "☐ Una vez   ☐ Se repite"],
        ["Nivel propuesto", "☐ Crítica   ☐ Alta   ☐ Media   ☐ Baja"],
    ], [5.0, 11.2])

    doc.add_heading("Recomendación final", level=1)
    add_checklist(doc, [
        "Puede pasar a una beta más amplia.",
        "Puede continuar después de cambios menores.",
        "Necesita cambios importantes antes de otra prueba.",
        "No puedo recomendar todavía su uso por el motivo indicado abajo.",
    ])
    doc.add_paragraph("Motivo: ____________________________________________________________________________")
    doc.add_paragraph("____________________________________________________________________________________")
    doc.add_paragraph("Comentarios finales:")
    for _ in range(6):
        doc.add_paragraph("____________________________________________________________________________________")
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    args = parser.parse_args()
    output = args.project.resolve() / "80_beta_privada"
    build_guide(output / "guia-prueba-beta.docx")
    build_questionnaire(output / "cuestionario-beta-docente.docx")
    print(f"Paquete documental beta creado en {output} (2 DOCX)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
