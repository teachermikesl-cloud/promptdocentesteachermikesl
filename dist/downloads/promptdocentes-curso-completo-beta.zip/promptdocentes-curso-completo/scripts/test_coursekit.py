#!/usr/bin/env python3

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).with_name("coursekit.py")


class CoursekitTests(unittest.TestCase):
    def run_tool(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(SCRIPT), *args],
            check=False,
            text=True,
            capture_output=True,
        )

    def test_init_and_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp) / "pilot"
            result = self.run_tool(
                "init", "--project", str(project), "--title", "Piloto",
                "--academic-year", "2026-2027", "--stage", "Educación Primaria",
                "--level", "3.º", "--subject", "Matemáticas",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((project / "00_control" / "curso.json").is_file())
            manifest = self.run_tool("manifest", "--project", str(project))
            self.assertEqual(manifest.returncode, 0, manifest.stderr)
            data = json.loads((project / "90_entrega" / "manifest.json").read_text(encoding="utf-8"))
            self.assertGreaterEqual(len(data["files"]), 3)

    def test_empty_project_fails_validation(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp) / "pilot"
            self.run_tool(
                "init", "--project", str(project), "--title", "Piloto",
                "--academic-year", "2026-2027", "--stage", "Educación Primaria",
                "--level", "3.º", "--subject", "Matemáticas",
            )
            result = self.run_tool("validate", "--project", str(project))
            self.assertEqual(result.returncode, 1)
            report = json.loads((project / "00_control" / "validacion.json").read_text(encoding="utf-8"))
            self.assertFalse(report["valid"])

    def test_complete_minimum_project_passes_strict_validation(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp) / "pilot"
            self.run_tool(
                "init", "--project", str(project), "--title", "Piloto",
                "--academic-year", "2026-2027", "--stage", "Educación Primaria",
                "--level", "3.º", "--subject", "Matemáticas",
            )
            config_path = project / "00_control" / "curso.json"
            config = json.loads(config_path.read_text(encoding="utf-8"))
            config["curriculum"]["sources"] = [{
                "id": "SRC-001", "title": "Fuente oficial", "url": "https://example.edu",
                "issuer": "Administración educativa", "scope": "Piloto",
                "status": "verified", "checked_on": "2026-09-26",
            }]
            config["curriculum"]["evaluation_criteria"] = [{"id": "CR-1", "text": "Criterio de prueba"}]
            config["sequence_map"] = [{
                "id": "SEQ-01", "term": 1, "title": "Secuencia piloto",
                "central_learning": "Aprendizaje de prueba",
                "performance_or_product": "Desempeño observable", "sessions": 4,
                "competency_ids": [], "criterion_ids": ["CR-1"], "status": "planned",
            }]
            config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            result = self.run_tool("validate", "--project", str(project), "--strict")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_load_pack_populates_curriculum(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = root / "pilot"
            self.run_tool(
                "init", "--project", str(project), "--title", "Piloto",
                "--academic-year", "2026-2027", "--stage", "ESO",
                "--level", "1.º", "--subject", "Matemáticas",
            )
            pack = root / "pack.json"
            pack.write_text(json.dumps({
                "pack_id": "test-pack", "verified_on": "2026-09-26",
                "content_status": {"evaluation_criteria": "Transcripción estructurada"},
                "verification": {"status": "verified_source_transcription"},
                "pending_checks": ["Confirmar vigencia normativa antes del uso institucional."],
                "context": {"territory": "Andalucía", "stage": "ESO", "level": "1.º", "subject": "Matemáticas"},
                "sources": [{"id": "S1", "title": "Fuente", "url": "https://example.edu", "status": "verified"}],
                "competencies": [{"id": "CE1", "text": "Competencia"}],
                "evaluation_criteria": [{"id": "1.1", "competency_id": "CE1", "text": "Criterio", "core_learning_ids": ["SB1"]}],
                "core_learning": {"SB1": "Saber"},
            }, ensure_ascii=False), encoding="utf-8")
            result = self.run_tool("load-pack", "--project", str(project), "--pack", str(pack))
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            config = json.loads((project / "00_control" / "curso.json").read_text(encoding="utf-8"))
            self.assertEqual(config["curriculum"]["pack_id"], "test-pack")
            self.assertEqual(len(config["curriculum"]["evaluation_criteria"]), 1)
            self.assertEqual(config["curriculum"]["verification"]["status"], "verified_source_transcription")
            self.assertEqual(len(config["curriculum"]["pending_checks"]), 1)
            self.assertIn("Comprobaciones pendientes: 1", result.stdout)

            validation = self.run_tool("validate", "--project", str(project))
            report = json.loads((project / "00_control" / "validacion.json").read_text(encoding="utf-8"))
            self.assertTrue(any("Comprobación curricular pendiente" in item for item in report["warnings"]))
            strict_validation = self.run_tool("validate", "--project", str(project), "--strict")
            self.assertEqual(strict_validation.returncode, 1)
            strict_report = json.loads((project / "00_control" / "validacion.json").read_text(encoding="utf-8"))
            self.assertTrue(any("Comprobación curricular pendiente" in item for item in strict_report["errors"]))

    def test_load_pack_rejects_wrong_subject(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = root / "pilot"
            self.run_tool(
                "init", "--project", str(project), "--title", "Piloto",
                "--academic-year", "2026-2027", "--stage", "ESO",
                "--level", "1.º", "--subject", "Educación Física",
            )
            pack = root / "pack.json"
            pack.write_text(json.dumps({
                "pack_id": "math-pack", "verified_on": "2026-09-26",
                "context": {"territory": "Andalucía", "stage": "ESO", "level": "1.º", "subject": "Matemáticas"},
                "sources": [], "competencies": [], "evaluation_criteria": [], "core_learning": {},
            }, ensure_ascii=False), encoding="utf-8")
            result = self.run_tool("load-pack", "--project", str(project), "--pack", str(pack))
            self.assertEqual(result.returncode, 2)
            self.assertIn("subject", result.stderr)

    def test_export_map_creates_reviewable_csv(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp) / "pilot"
            self.run_tool(
                "init", "--project", str(project), "--title", "Piloto",
                "--academic-year", "2026-2027", "--stage", "ESO",
                "--level", "1.º", "--subject", "Matemáticas",
            )
            config_path = project / "00_control" / "curso.json"
            config = json.loads(config_path.read_text(encoding="utf-8"))
            config["sequence_map"] = [{
                "id": "SEQ-01", "term": 1, "title": "Datos",
                "central_learning": "Variables", "performance_or_product": "Informe",
                "sessions": 5, "competency_ids": ["CE1", "CE3"],
                "criterion_ids": ["1.1", "3.3"], "status": "planned",
            }]
            config_path.write_text(json.dumps(config, ensure_ascii=False), encoding="utf-8")
            result = self.run_tool("export-map", "--project", str(project))
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            exported = (project / "10_diseno_anual" / "mapa-curricular.csv").read_text(encoding="utf-8")
            self.assertIn("CE1;CE3", exported)
            self.assertIn("1.1;3.3", exported)

    def test_present_creates_iconized_teacher_view(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp) / "pilot"
            self.run_tool(
                "init", "--project", str(project), "--title", "Curso atractivo",
                "--academic-year", "2026-2027", "--stage", "ESO",
                "--level", "1.º", "--subject", "Educación Física",
            )
            config_path = project / "00_control" / "curso.json"
            config = json.loads(config_path.read_text(encoding="utf-8"))
            config["sequence_map"] = [{
                "id": "SEQ-01", "term": 1, "title": "Cooperar / decidir", "icon": "🤝",
                "central_learning": "Cooperación", "performance_or_product": "Reto",
                "sessions": 3, "competency_ids": [], "criterion_ids": [], "status": "planned",
            }]
            config_path.write_text(json.dumps(config, ensure_ascii=False), encoding="utf-8")
            sequence = project / "20_secuencias" / "SEQ-01"
            (sequence / "recursos").mkdir(parents=True)
            (sequence / "guia-docente.md").write_text("# Guía\n", encoding="utf-8")
            (sequence / "material-alumnado.md").write_text("# Material\n", encoding="utf-8")
            (sequence / "evaluacion.csv").write_text("criterio,evidencia\n", encoding="utf-8")
            (sequence / "recursos" / "tarjetas-retos.md").write_text("# Tarjetas\n", encoding="utf-8")
            (sequence / "documentos-editables").mkdir()
            (sequence / "documentos-editables" / "guia-docente.docx").write_bytes(b"docx-placeholder")
            (sequence / "documentos-editables" / "guia-paso-a-paso.docx").write_bytes(b"docx-placeholder")
            (sequence / "documentos-editables" / "refuerzo-apoyo.docx").write_bytes(b"docx-placeholder")
            (sequence / "documentos-editables" / "ampliacion-enriquecimiento.docx").write_bytes(b"docx-placeholder")
            (sequence / "documentos-editables" / "apoyos-accesibilidad.docx").write_bytes(b"docx-placeholder")
            (sequence / "documentos-editables" / "registro-evaluacion.xlsx").write_bytes(b"xlsx-placeholder")

            result = self.run_tool("present", "--project", str(project))
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            view = project / "90_entrega" / "📦 Proyecto docente"
            sequence_view = view / "🍂 20 · 1.er trimestre" / "🤝 SEQ-01 · Cooperar - decidir"
            self.assertTrue((view / "🧭 00 · Empieza aquí" / "🧭 Índice visual.md").is_file())
            panel = (view / "🧭 00 · Empieza aquí" / "🧭 Panel de navegación.html").read_text(encoding="utf-8")
            self.assertIn("PromptDocentes · Teacher MikeSL", panel)
            self.assertIn("SEQ-01 · Cooperar - decidir", panel)
            self.assertTrue((sequence_view / "📘 Guía docente" / "📘 Guía docente.md").is_file())
            self.assertTrue((sequence_view / "📘 Guía docente" / "📘 Guía docente.docx").is_file())
            self.assertTrue((sequence_view / "📘 Guía docente" / "🧭 Guía paso a paso.docx").is_file())
            self.assertTrue((sequence_view / "🎯 Evaluación" / "📊 Registro de evaluación.xlsx").is_file())
            self.assertTrue((sequence_view / "🧩 Apoyos y accesibilidad" / "🛟 Refuerzo y apoyo.docx").is_file())
            self.assertTrue((sequence_view / "🧩 Apoyos y accesibilidad" / "🧩 Apoyos y accesibilidad.docx").is_file())
            self.assertTrue((sequence_view / "🚀 Ampliación y enriquecimiento" / "🚀 Ampliación y enriquecimiento.docx").is_file())
            self.assertTrue((sequence_view / "🧰 Recursos" / "🎲 Tarjetas para la práctica.md").is_file())


if __name__ == "__main__":
    unittest.main()
