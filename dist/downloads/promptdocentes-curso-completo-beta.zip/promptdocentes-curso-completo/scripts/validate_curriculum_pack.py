#!/usr/bin/env python3
"""Comprueba integridad y trazabilidad interna de un paquete curricular JSON."""

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pack", type=Path)
    args = parser.parse_args()
    data = json.loads(args.pack.read_text(encoding="utf-8"))
    errors = []

    if not str(data.get("verification", {}).get("status", "")).strip():
        errors.append("Falta verification.status")
    if not isinstance(data.get("content_status", {}), dict):
        errors.append("content_status debe ser un objeto")
    if not isinstance(data.get("pending_checks", []), list):
        errors.append("pending_checks debe ser una lista")

    context = data.get("context", {})
    for field in ("territory", "stage", "level", "subject"):
        if not str(context.get(field, "")).strip():
            errors.append(f"Falta context.{field}")

    competencies = data.get("competencies", [])
    criteria = data.get("evaluation_criteria", [])
    learning = data.get("core_learning", {})
    competency_ids = [item.get("id") for item in competencies]
    criterion_ids = [item.get("id") for item in criteria]

    if len(set(competency_ids)) != len(competency_ids):
        errors.append("Hay competencias duplicadas")
    if len(set(criterion_ids)) != len(criterion_ids):
        errors.append("Hay criterios duplicados")
    if any(not item.get("text") for item in competencies + criteria):
        errors.append("Hay competencias o criterios sin texto")

    competency_set = set(competency_ids)
    learning_set = set(learning)
    for criterion in criteria:
        if criterion.get("competency_id") not in competency_set:
            errors.append(f"{criterion.get('id')}: competencia desconocida {criterion.get('competency_id')}")
        for learning_id in criterion.get("core_learning_ids", []):
            if learning_id not in learning_set:
                errors.append(f"{criterion.get('id')}: saber desconocido {learning_id}")

    for source in data.get("sources", []):
        if source.get("status") != "verified" or not str(source.get("url", "")).startswith("https://"):
            errors.append(f"Fuente no verificada o URL insegura: {source.get('id', '(sin id)')}")

    print(f"Competencias: {len(competencies)}")
    print(f"Criterios: {len(criteria)}")
    print(f"Saberes y epígrafes: {len(learning)}")
    print(f"Fuentes: {len(data.get('sources', []))}")
    for error in errors:
        print(f"ERROR: {error}")
    print("PAQUETE VÁLIDO" if not errors else f"PAQUETE NO VÁLIDO: {len(errors)} error(es)")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
