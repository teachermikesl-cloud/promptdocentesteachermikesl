#!/usr/bin/env node

const fs = require("node:fs");
const path = require("node:path");
const { Workbook, SpreadsheetFile } = require("@oai/artifact-tool");

const NAVY = "#38527D";
const TEAL = "#159A83";
const PALE = "#F2F5FA";
const LIGHT_GREEN = "#E8F5F0";
const LIGHT_AMBER = "#FFF5D6";
const LIGHT_RED = "#FCE8E6";
const BORDER = "#D7DDE7";
const TEXT = "#263A59";
const FONT = "Aptos";

function getArg(name) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

function readCsv(filePath) {
  const text = fs.readFileSync(filePath, "utf8").trim();
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (char === '"') {
      if (quoted && text[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else {
        quoted = !quoted;
      }
    } else if (char === "," && !quoted) {
      row.push(cell);
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && text[i + 1] === "\n") i += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  row.push(cell);
  rows.push(row);
  const headers = rows.shift();
  return rows.map((values) => Object.fromEntries(headers.map((header, i) => [header, values[i] || ""])));
}

function columnName(number) {
  let value = number;
  let result = "";
  while (value > 0) {
    value -= 1;
    result = String.fromCharCode(65 + (value % 26)) + result;
    value = Math.floor(value / 26);
  }
  return result;
}

function shortFocus(item) {
  return item.focus || item.observable_focus || item.evidence || `Desempeño vinculado al criterio ${item.criterion_id}`;
}

function rubricLevel(item, key, fallback) {
  return (item[key] || "").trim() || fallback;
}

function baseSheet(sheet, tabColor) {
  sheet.showGridLines = false;
  sheet.tabColor = tabColor;
}

function titleBlock(sheet, range, title, subtitle) {
  sheet.mergeCells(range);
  const start = range.split(":")[0];
  sheet.getRange(start).values = [[title]];
  sheet.getRange(range).format = {
    fill: NAVY,
    font: { name: FONT, size: 18, bold: true, color: "#FFFFFF" },
    verticalAlignment: "center",
  };
  sheet.getRange(range).format.rowHeight = 34;
  const row = Number(start.match(/\d+/)[0]) + 1;
  const cols = range.match(/[A-Z]+/g);
  const subtitleRange = `${cols[0]}${row}:${cols[1]}${row}`;
  sheet.mergeCells(subtitleRange);
  sheet.getRange(`${cols[0]}${row}`).values = [[subtitle]];
  sheet.getRange(subtitleRange).format = {
    fill: LIGHT_GREEN,
    font: { name: FONT, size: 10, italic: true, color: TEXT },
    wrapText: true,
    verticalAlignment: "center",
  };
  sheet.getRange(subtitleRange).format.rowHeight = 30;
}

function styleHeader(range) {
  range.format = {
    fill: NAVY,
    font: { name: FONT, size: 10, bold: true, color: "#FFFFFF" },
    wrapText: true,
    verticalAlignment: "center",
    borders: { preset: "all", style: "thin", color: BORDER },
  };
}

function styleBody(range) {
  range.format = {
    wrapText: true,
    verticalAlignment: "top",
    borders: { preset: "all", style: "thin", color: BORDER },
  };
}

async function main() {
  const project = getArg("--project");
  const sequenceId = getArg("--sequence") || "SEQ-04";
  const previewDir = getArg("--preview-dir");
  if (!project) throw new Error("Uso: --project <ruta> [--sequence SEQ-XX] [--preview-dir <ruta>]");

  const control = JSON.parse(fs.readFileSync(path.join(project, "00_control", "curso.json"), "utf8"));
  const sequence = control.sequence_map.find((item) => item.id === sequenceId);
  if (!sequence) throw new Error(`No existe ${sequenceId} en 00_control/curso.json`);
  const sequenceDir = path.join(project, "20_secuencias", sequenceId);
  const evaluation = readCsv(path.join(sequenceDir, "evaluacion.csv"));
  const criterionIds = [...new Set(evaluation.map((item) => item.criterion_id).filter(Boolean))];
  if (criterionIds.length === 0) throw new Error("evaluacion.csv no contiene criterion_id");
  const criterionById = new Map(control.curriculum.evaluation_criteria.map((item) => [item.id, item]));
  const stageLevel = `${control.context.stage} · ${control.context.level}`;
  const registerCriterionStart = 4;
  const registerCriterionEnd = registerCriterionStart + criterionIds.length - 1;
  const evidenceColumn = registerCriterionEnd + 1;
  const nextStepColumn = evidenceColumn + 1;
  const lastColumn = columnName(nextStepColumn);
  const firstCriterionLetter = columnName(registerCriterionStart);
  const lastCriterionLetter = columnName(registerCriterionEnd);
  const evidenceLetter = columnName(evidenceColumn);
  const nextStepLetter = columnName(nextStepColumn);
  const outputDir = path.join(sequenceDir, "documentos-editables");
  fs.mkdirSync(outputDir, { recursive: true });
  if (previewDir) fs.mkdirSync(previewDir, { recursive: true });

  const workbook = Workbook.create();
  const registro = workbook.worksheets.add("Registro");
  const rubrica = workbook.worksheets.add("Rúbrica");
  const fuentes = workbook.worksheets.add("Fuentes");
  baseSheet(registro, TEAL);
  baseSheet(rubrica, NAVY);
  baseSheet(fuentes, "#6B7280");

  titleBlock(
    registro,
    `A1:${lastColumn}1`,
    `Registro de evaluación · ${sequence.title}`,
    `${sequenceId} · ${control.context.subject} · ${control.context.level} · PromptDocentes · Teacher MikeSL. Use códigos internos únicamente en la copia protegida del centro.`
  );
  const registerHeader = ["Código interno", "Fecha", "Sesión", ...criterionIds, "Evidencia breve", "Próximo paso"];
  registro.getRange(`A4:${lastColumn}4`).values = [registerHeader];
  styleHeader(registro.getRange(`A4:${lastColumn}4`));
  registro.getRange(`A5:${lastColumn}34`).values = Array.from({ length: 30 }, () => Array(registerHeader.length).fill(""));
  styleBody(registro.getRange(`A5:${lastColumn}34`));
  for (let row = 5; row <= 34; row += 1) {
    if (row % 2 === 0) registro.getRange(`A${row}:${lastColumn}${row}`).format.fill = PALE;
  }
  registro.getRange(`${firstCriterionLetter}5:${lastCriterionLetter}34`).dataValidation = { rule: { type: "list", values: ["NO", "AP", "FR", "AU"] } };
  registro.getRange("C5:C34").dataValidation = { rule: { type: "list", values: Array.from({ length: sequence.sessions }, (_, index) => String(index + 1)) } };
  registro.getRange("B5:B34").format.numberFormat = "dd/mm/yyyy";
  const criterionRange = registro.getRange(`${firstCriterionLetter}5:${lastCriterionLetter}34`);
  criterionRange.conditionalFormats.add("cellIs", { operator: "equal", formula: '"AU"', format: { fill: LIGHT_GREEN, font: { color: "#0B6B57", bold: true } } });
  criterionRange.conditionalFormats.add("cellIs", { operator: "equal", formula: '"AP"', format: { fill: LIGHT_AMBER, font: { color: "#7A5A00" } } });
  criterionRange.conditionalFormats.add("cellIs", { operator: "equal", formula: '"NO"', format: { fill: LIGHT_RED, font: { color: "#8A2F27" } } });
  registro.getRange(`A36:${lastColumn}36`).values = [["Leyenda", "NO · no observado", "AP · con ayuda", "FR · frecuente", "AU · autónomo", ...Array(Math.max(0, registerHeader.length - 5)).fill("")]];
  registro.getRange(`A36:${lastColumn}36`).format = { fill: "#EEF2F7", font: { name: FONT, size: 9, bold: true, color: TEXT }, wrapText: true, borders: { preset: "all", style: "thin", color: BORDER } };
  registro.getRange(`A38:${lastColumn}38`).values = [["Privacidad", ...Array(registerHeader.length - 1).fill("")]];
  registro.mergeCells("A38:C38");
  registro.mergeCells(`D38:${lastColumn}38`);
  registro.getRange("A38").values = [["Privacidad"]];
  registro.getRange("D38").values = [["No introduzca nombres ni códigos identificativos en herramientas externas de IA."]];
  registro.getRange(`A38:${lastColumn}38`).format = { fill: LIGHT_AMBER, font: { name: FONT, size: 10, bold: true, color: TEXT }, wrapText: true, borders: { preset: "all", style: "thin", color: BORDER } };
  registro.freezePanes.freezeRows(4);
  registro.getRange("A:A").format.columnWidth = 16;
  registro.getRange("B:B").format.columnWidth = 12;
  registro.getRange("C:C").format.columnWidth = 9;
  registro.getRange(`${firstCriterionLetter}:${lastCriterionLetter}`).format.columnWidth = 10;
  registro.getRange(`${evidenceLetter}:${nextStepLetter}`).format.columnWidth = 28;
  registro.getRange("4:38").format.autofitRows();
  registro.getRange(`A1:${lastColumn}38`).format.font.name = FONT;

  const rubricRows = evaluation.map((item) => {
    const focus = shortFocus(item);
    const official = criterionById.get(item.criterion_id);
    const label = `${item.criterion_id} · ${item.short_label || (official ? official.competency_id : "Criterio")}`;
    return [
      label,
      rubricLevel(item, "rubric_initial", `Necesita ayuda frecuente para mostrar ${focus.toLowerCase()} y todavía no aporta una evidencia suficiente.`),
      rubricLevel(item, "rubric_developing", `Muestra parcialmente ${focus.toLowerCase()} con recordatorios o en situaciones facilitadas.`),
      rubricLevel(item, "rubric_adequate", `Muestra ${focus.toLowerCase()} de forma consistente y lo respalda con una evidencia pertinente.`),
      rubricLevel(item, "rubric_advanced", `Actúa con autonomía, justifica sus decisiones y transfiere ${focus.toLowerCase()} a una situación nueva.`),
    ];
  });
  titleBlock(rubrica, "A1:E1", `Rúbrica analítica · ${sequence.title}`, `Criterios ${criterionIds.join(", ")} · ${stageLevel}. Los niveles describen progreso sobre el mismo foco.`);
  rubrica.getRange("A4:E4").values = [["Foco curricular", "Inicial", "En desarrollo", "Adecuado", "Avanzado"]];
  styleHeader(rubrica.getRange("A4:E4"));
  const rubricEndRow = 4 + rubricRows.length;
  rubrica.getRange(`A5:E${rubricEndRow}`).values = rubricRows;
  styleBody(rubrica.getRange(`A5:E${rubricEndRow}`));
  rubrica.getRange(`A5:A${rubricEndRow}`).format.font = { name: FONT, size: 10, bold: true, color: TEXT };
  rubrica.getRange(`A5:E${rubricEndRow}`).format.rowHeight = 102;
  rubrica.getRange("A:E").format.columnWidth = 28;
  rubrica.getRange(`A1:E${rubricEndRow}`).format.font.name = FONT;
  rubrica.freezePanes.freezeRows(4);

  titleBlock(fuentes, "A1:E1", "Fuentes curriculares verificadas", "Referencias incorporadas al proyecto. Las concreciones didácticas son propuestas del recurso y no sustituyen la lectura de la norma oficial.");
  fuentes.getRange("A4:E4").values = [["ID", "Fuente", "Ámbito", "Estado", "Enlace oficial"]];
  styleHeader(fuentes.getRange("A4:E4"));
  const sourceRows = control.curriculum.sources.map((source) => [source.id, source.title, source.scope, `${source.status} · ${source.checked_on}`, source.url]);
  fuentes.getRange(`A5:E${4 + sourceRows.length}`).values = sourceRows;
  styleBody(fuentes.getRange(`A5:E${4 + sourceRows.length}`));
  fuentes.getRange(`E5:E${4 + sourceRows.length}`).format.font = { name: FONT, size: 9, color: "#1155CC", underline: "single" };
  fuentes.getRange("A:A").format.columnWidth = 12;
  fuentes.getRange("B:B").format.columnWidth = 48;
  fuentes.getRange("C:C").format.columnWidth = 32;
  fuentes.getRange("D:D").format.columnWidth = 20;
  fuentes.getRange("E:E").format.columnWidth = 55;
  fuentes.getRange(`5:${4 + sourceRows.length}`).format.rowHeight = 54;
  fuentes.getRange("A11:E11").values = [["Trazabilidad de la secuencia", "Criterio", "Momento", "Evidencia", "Uso formativo"]];
  styleHeader(fuentes.getRange("A11:E11"));
  fuentes.getRange(`A12:E${11 + evaluation.length}`).values = evaluation.map((item) => [sequenceId, item.criterion_id, item.activity_or_moment, item.evidence, item.formative_use]);
  styleBody(fuentes.getRange(`A12:E${11 + evaluation.length}`));
  fuentes.getRange(`A12:E${11 + evaluation.length}`).format.rowHeight = 62;
  fuentes.getRange(`A1:E${11 + evaluation.length}`).format.font.name = FONT;
  fuentes.freezePanes.freezeRows(4);

  workbook.recalculate();
  if (previewDir) {
    for (const name of ["Registro", "Rúbrica", "Fuentes"]) {
      const preview = await workbook.render({ sheetName: name, autoCrop: "all", scale: 1, format: "png" });
      fs.writeFileSync(path.join(previewDir, `${name.toLowerCase()}.png`), new Uint8Array(await preview.arrayBuffer()));
    }
  }
  const outputPath = path.join(outputDir, "registro-evaluacion.xlsx");
  const xlsx = await SpreadsheetFile.exportXlsx(workbook);
  await xlsx.save(outputPath);
  process.stdout.write(`${outputPath}\nHojas: Registro, Rúbrica, Fuentes\n`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
