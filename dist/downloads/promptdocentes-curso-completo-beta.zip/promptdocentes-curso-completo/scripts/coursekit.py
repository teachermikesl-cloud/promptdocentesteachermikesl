#!/usr/bin/env python3
"""Inicializa y valida proyectos originales de PromptDocentes · Curso completo."""

from __future__ import annotations

import argparse
import csv
import hashlib
import html as html_lib
import json
import re
import shutil
import sys
from datetime import date
from pathlib import Path
from urllib.parse import quote

SCHEMA_VERSION = "1.0"
CONTROL = "00_control"
REQUIRED_DIRS = (
    CONTROL,
    "10_diseno_anual",
    "20_secuencias",
    "30_recursos_comunes/instrumentos",
    "30_recursos_comunes/plantillas",
    "90_entrega",
)
PRESENTATION_ROOT = "📦 Proyecto docente"
TERM_FOLDERS = {
    1: "🍂 20 · 1.er trimestre",
    2: "❄️ 30 · 2.º trimestre",
    3: "🌱 40 · 3.er trimestre",
}


def load_config(project: Path) -> dict:
    path = project / CONTROL / "curso.json"
    if not path.is_file():
        raise ValueError(f"Falta {path}")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"JSON no válido en {path}: {exc}") from exc


def write_json(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def safe_id(value: str) -> bool:
    return bool(re.fullmatch(r"SEQ-[0-9]{2}", value))


def display_name(value: object) -> str:
    """Return a portable human-facing file or folder name."""
    text = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "-", str(value)).strip().strip(".")
    return re.sub(r"\s+", " ", text) or "Sin título"


def copy_if_present(source: Path, target: Path) -> bool:
    if not source.is_file():
        return False
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    return True


def command_init(args: argparse.Namespace) -> int:
    project = args.project.resolve()
    if project.exists() and any(project.iterdir()):
        print(f"ERROR: la carpeta no está vacía: {project}", file=sys.stderr)
        return 2
    for folder in REQUIRED_DIRS:
        (project / folder).mkdir(parents=True, exist_ok=True)

    config = {
        "schema_version": SCHEMA_VERSION,
        "project": {
            "title": args.title,
            "academic_year": args.academic_year,
            "owner": args.owner,
            "status": "draft",
        },
        "context": {
            "territory": "Andalucía",
            "stage": args.stage,
            "level": args.level,
            "subject": args.subject,
            "language": "es",
        },
        "curriculum": {
            "model": args.model,
            "sources": [],
            "competencies": [],
            "evaluation_criteria": [],
            "core_learning": [],
        },
        "learners": {"profile": "", "access_needs": [], "interests": []},
        "design": {
            "weekly_sessions": 0,
            "estimated_weeks": 0,
            "methodological_choices": [],
            "assessment_choices": [],
        },
        "sequence_map": [],
        "outputs": {
            "teacher_guides": True,
            "learner_materials": True,
            "assessment_tools": True,
            "accessible_alternatives": True,
            "interactive_resources": False,
        },
    }
    write_json(project / CONTROL / "curso.json", config)
    write_json(
        project / CONTROL / "estado.json",
        {"schema_version": SCHEMA_VERSION, "stage": "draft", "updated_on": str(date.today())},
    )
    (project / CONTROL / "decisiones.md").write_text(
        "# Registro de decisiones\n\nAñade fecha, decisión, responsable y motivo.\n",
        encoding="utf-8",
    )
    with (project / CONTROL / "fuentes.csv").open("w", newline="", encoding="utf-8") as handle:
        csv.writer(handle).writerow(
            ["id", "title", "url", "issuer", "scope", "status", "checked_on"]
        )
    print(f"Proyecto creado: {project}")
    print(f"Siguiente paso: completar {CONTROL}/curso.json y verificar las fuentes curriculares.")
    return 0


def collect_errors(project: Path, config: dict, strict: bool) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if config.get("schema_version") != SCHEMA_VERSION:
        errors.append(f"schema_version debe ser {SCHEMA_VERSION}")

    for section in ("project", "context", "curriculum", "learners", "design", "sequence_map", "outputs"):
        if section not in config:
            errors.append(f"Falta la sección {section}")

    context = config.get("context", {})
    for field in ("territory", "stage", "level", "subject"):
        if not str(context.get(field, "")).strip():
            errors.append(f"context.{field} está vacío")

    curriculum = config.get("curriculum", {})
    sources = curriculum.get("sources", [])
    verified_sources = [s for s in sources if s.get("status") == "verified" and s.get("url")]
    if not verified_sources:
        errors.append("No hay ninguna fuente curricular oficial marcada como verificada")

    criteria = curriculum.get("evaluation_criteria", [])
    criterion_ids = {item.get("id") for item in criteria if item.get("id")}
    if not criterion_ids:
        errors.append("No hay criterios de evaluación identificados")

    sequence_ids: set[str] = set()
    used_criteria: set[str] = set()
    for index, sequence in enumerate(config.get("sequence_map", []), start=1):
        sequence_id = sequence.get("id", "")
        if not safe_id(sequence_id):
            errors.append(f"Secuencia {index}: id inválido; usa SEQ-01, SEQ-02…")
        if sequence_id in sequence_ids:
            errors.append(f"Identificador de secuencia duplicado: {sequence_id}")
        sequence_ids.add(sequence_id)
        for field in ("title", "central_learning", "performance_or_product"):
            if not str(sequence.get(field, "")).strip():
                errors.append(f"{sequence_id or index}: falta {field}")
        if not isinstance(sequence.get("sessions"), int) or sequence.get("sessions", 0) <= 0:
            errors.append(f"{sequence_id or index}: sessions debe ser un entero positivo")
        for criterion_id in sequence.get("criterion_ids", []):
            used_criteria.add(criterion_id)
            if criterion_id not in criterion_ids:
                errors.append(f"{sequence_id or index}: criterio desconocido {criterion_id}")

    if not config.get("sequence_map"):
        errors.append("El mapa anual no contiene secuencias")
    unused = sorted(criterion_ids - used_criteria)
    if unused:
        message = "Criterios sin cobertura: " + ", ".join(unused)
        (errors if strict else warnings).append(message)

    for folder in REQUIRED_DIRS:
        if not (project / folder).is_dir():
            errors.append(f"Falta la carpeta {folder}")
    return errors, warnings


def command_validate(args: argparse.Namespace) -> int:
    project = args.project.resolve()
    try:
        config = load_config(project)
        errors, warnings = collect_errors(project, config, args.strict)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    report = {
        "schema_version": SCHEMA_VERSION,
        "checked_on": str(date.today()),
        "strict": args.strict,
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
    }
    write_json(project / CONTROL / "validacion.json", report)
    for item in errors:
        print(f"ERROR: {item}")
    for item in warnings:
        print(f"AVISO: {item}")
    print("VALIDACIÓN SUPERADA" if not errors else f"VALIDACIÓN FALLIDA: {len(errors)} error(es)")
    return 0 if not errors else 1


def command_status(args: argparse.Namespace) -> int:
    project = args.project.resolve()
    try:
        config = load_config(project)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    project_data = config.get("project", {})
    context = config.get("context", {})
    print(f"Proyecto: {project_data.get('title') or '(sin título)'}")
    print(f"Estado: {project_data.get('status') or 'draft'}")
    print(f"Curso: {context.get('stage', '')} · {context.get('level', '')} · {context.get('subject', '')}")
    print(f"Fuentes: {len(config.get('curriculum', {}).get('sources', []))}")
    print(f"Secuencias: {len(config.get('sequence_map', []))}")
    return 0


def command_manifest(args: argparse.Namespace) -> int:
    project = args.project.resolve()
    if not project.is_dir():
        print(f"ERROR: no existe {project}", file=sys.stderr)
        return 2
    files = []
    manifest_path = project / "90_entrega" / "manifest.json"
    for path in sorted(p for p in project.rglob("*") if p.is_file() and p != manifest_path):
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        files.append({"path": path.relative_to(project).as_posix(), "sha256": digest, "bytes": path.stat().st_size})
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    write_json(
        manifest_path,
        {"schema_version": SCHEMA_VERSION, "created_on": str(date.today()), "files": files},
    )
    print(f"Manifiesto creado: {manifest_path} ({len(files)} archivos)")
    return 0


def command_present(args: argparse.Namespace) -> int:
    project = args.project.resolve()
    try:
        config = load_config(project)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    presentation = project / "90_entrega" / PRESENTATION_ROOT
    if presentation.exists():
        shutil.rmtree(presentation)
    start = presentation / "🧭 00 · Empieza aquí"
    annual = presentation / "🗺️ 10 · Diseño anual"
    beta = presentation / "🧪 70 · Beta privada"
    sources = presentation / "📜 80 · Fuentes y verificación"
    beta_source = project / "80_beta_privada"
    folders = [start, annual, sources, *(presentation / value for value in TERM_FOLDERS.values())]
    if beta_source.is_dir():
        folders.append(beta)
    for folder in folders:
        folder.mkdir(parents=True, exist_ok=True)

    copied = 0
    copied += copy_if_present(project / "10_diseno_anual" / "mapa-anual-propuesto.md", annual / "📅 Mapa anual.md")
    copied += copy_if_present(project / "10_diseno_anual" / "mapa-curricular.csv", annual / "🧩 Mapa curricular.csv")
    copied += copy_if_present(project / CONTROL / "fuentes.csv", sources / "📚 Fuentes curriculares.csv")
    copied += copy_if_present(project / CONTROL / "validacion.json", sources / "✅ Informe de validación.json")
    beta_copied = False
    if beta_source.is_dir():
        beta_copied |= copy_if_present(beta_source / "guia-prueba-beta.docx", beta / "📘 Guía de prueba beta.docx")
        beta_copied |= copy_if_present(beta_source / "cuestionario-beta-docente.docx", beta / "📝 Cuestionario beta docente.docx")
        beta_copied |= copy_if_present(beta_source / "registro-beta-privada.xlsx", beta / "📊 Registro beta privada.xlsx")
        copied += sum(1 for name in ("📘 Guía de prueba beta.docx", "📝 Cuestionario beta docente.docx", "📊 Registro beta privada.xlsx") if (beta / name).is_file())

    resource_names = {
        "tarjetas-retos": "🎲 Tarjetas para la práctica",
        "instrumentos-evaluacion": "📋 Instrumentos de evaluación",
        "soluciones-y-criterios": "✅ Soluciones y criterios",
        "apoyos": "🧩 Apoyos de acceso",
        "refuerzo": "🛟 Refuerzo y apoyo",
        "ampliacion": "🚀 Ampliación y enriquecimiento",
        "ampliación": "🚀 Ampliación y enriquecimiento",
        "guia-paso-a-paso": "🧭 Guía paso a paso",
    }
    listed_sequences = []
    for sequence in config.get("sequence_map", []):
        sequence_id = sequence.get("id", "")
        term = sequence.get("term")
        source_dir = project / "20_secuencias" / sequence_id
        if not source_dir.is_dir() or term not in TERM_FOLDERS:
            continue
        icon = str(sequence.get("icon") or "📚").strip().split()[0]
        title = display_name(sequence.get("title", "Secuencia"))
        target_dir = presentation / TERM_FOLDERS[term] / f"{icon} {sequence_id} · {title}"
        teacher_dir = target_dir / "📘 Guía docente"
        student_dir = target_dir / "✏️ Material del alumnado"
        assessment_dir = target_dir / "🎯 Evaluación"
        resources_dir = target_dir / "🧰 Recursos"
        support_dir = target_dir / "🧩 Apoyos y accesibilidad"
        extension_dir = target_dir / "🚀 Ampliación y enriquecimiento"
        for section_dir in (teacher_dir, student_dir, assessment_dir, resources_dir, support_dir, extension_dir):
            section_dir.mkdir(parents=True, exist_ok=True)
        copied += copy_if_present(source_dir / "guia-docente.md", teacher_dir / "📘 Guía docente.md")
        copied += copy_if_present(source_dir / "material-alumnado.md", student_dir / "✏️ Material del alumnado.md")
        copied += copy_if_present(source_dir / "evaluacion.csv", assessment_dir / "🎯 Matriz de evaluación.csv")
        editable_dir = source_dir / "documentos-editables"
        copied += copy_if_present(editable_dir / "guia-docente.docx", teacher_dir / "📘 Guía docente.docx")
        copied += copy_if_present(editable_dir / "guia-paso-a-paso.docx", teacher_dir / "🧭 Guía paso a paso.docx")
        copied += copy_if_present(editable_dir / "material-alumnado.docx", student_dir / "✏️ Material del alumnado.docx")
        copied += copy_if_present(editable_dir / "evaluacion-y-soluciones.docx", assessment_dir / "🎯 Evaluación y soluciones.docx")
        copied += copy_if_present(editable_dir / "registro-evaluacion.xlsx", assessment_dir / "📊 Registro de evaluación.xlsx")
        copied += copy_if_present(editable_dir / "tarjetas-retos.docx", resources_dir / "🎲 Tarjetas para la práctica.docx")
        copied += copy_if_present(editable_dir / "refuerzo-apoyo.docx", support_dir / "🛟 Refuerzo y apoyo.docx")
        copied += copy_if_present(editable_dir / "apoyos-accesibilidad.docx", support_dir / "🧩 Apoyos y accesibilidad.docx")
        copied += copy_if_present(editable_dir / "ampliacion-enriquecimiento.docx", extension_dir / "🚀 Ampliación y enriquecimiento.docx")
        resource_source = source_dir / "recursos"
        if resource_source.is_dir():
            for source_file in sorted(path for path in resource_source.iterdir() if path.is_file()):
                lowered = source_file.stem.casefold()
                label = next((value for key, value in resource_names.items() if key in lowered), None)
                if label is None:
                    label = f"📎 {display_name(source_file.stem).replace('-', ' ')}"
                target_name = f"{label}{source_file.suffix}"
                if "guia-paso-a-paso" in lowered:
                    destination = teacher_dir
                elif any(key in lowered for key in ("ampliacion", "ampliación")):
                    destination = extension_dir
                elif any(key in lowered for key in ("apoyos", "refuerzo")):
                    destination = support_dir
                else:
                    destination = resources_dir
                copied += copy_if_present(source_file, destination / target_name)
        listed_sequences.append((term, sequence_id, icon, title))

    index_lines = [
        f"# 🧭 {config.get('project', {}).get('title', 'Proyecto docente')}",
        "",
        "## Cómo empezar",
        "",
        "1. Consulta el mapa anual para comprender la progresión del curso.",
        "2. Abre la secuencia que vayas a aplicar y revisa primero su guía docente.",
        "3. Prepara los materiales, instrumentos y apoyos indicados antes de la sesión.",
        "4. Contrasta siempre los datos del grupo y los recursos reales del centro.",
        "",
        "## Accesos",
        "",
        "- [📅 Mapa anual](<../🗺️ 10 · Diseño anual/📅 Mapa anual.md>)",
        "- [🧩 Mapa curricular](<../🗺️ 10 · Diseño anual/🧩 Mapa curricular.csv>)",
        "- [📚 Fuentes curriculares](<../📜 80 · Fuentes y verificación/📚 Fuentes curriculares.csv>)",
        "- [✅ Informe de validación](<../📜 80 · Fuentes y verificación/✅ Informe de validación.json>)",
    ]
    if beta_copied:
        index_lines.extend([
            "- [📘 Guía de prueba beta](<../🧪 70 · Beta privada/📘 Guía de prueba beta.docx>)",
            "- [📝 Cuestionario beta docente](<../🧪 70 · Beta privada/📝 Cuestionario beta docente.docx>)",
            "- [📊 Registro beta privada](<../🧪 70 · Beta privada/📊 Registro beta privada.xlsx>)",
        ])
    index_lines.extend(["", "## Secuencias disponibles", ""])
    if listed_sequences:
        for term, sequence_id, icon, title in sorted(listed_sequences):
            folder = TERM_FOLDERS[term]
            index_lines.append(f"- {icon} **{sequence_id} · {title}** — `{folder}`")
    else:
        index_lines.append("- Todavía no hay secuencias completas en la vista docente.")
    index_lines.extend([
        "",
        "---",
        "",
        "**PromptDocentes · Teacher MikeSL**  ",
        "Vista de consulta generada desde los originales canónicos del proyecto.",
        "",
    ])
    index_path = start / "🧭 Índice visual.md"
    index_path.write_text("\n".join(index_lines), encoding="utf-8")
    copied += 1
    cards = [
        ("🗺️", "Mapa anual", "Consulta la progresión, los productos y la temporalización.", "../🗺️ 10 · Diseño anual/📅 Mapa anual.md"),
        ("🧩", "Mapa curricular", "Revisa la cobertura de competencias y criterios.", "../🗺️ 10 · Diseño anual/🧩 Mapa curricular.csv"),
        ("📚", "Fuentes curriculares", "Identifica la normativa y el estado de verificación.", "../📜 80 · Fuentes y verificación/📚 Fuentes curriculares.csv"),
    ]
    if beta_copied:
        cards.append(("🧪", "Prueba beta privada", "Sigue la guía, recoge respuestas anónimas y consolida las incidencias.", "../🧪 70 · Beta privada/📘 Guía de prueba beta.docx"))
    for term, sequence_id, icon, title in sorted(listed_sequences):
        folder = TERM_FOLDERS[term]
        sequence_folder = f"{icon} {sequence_id} · {title}"
        cards.append((icon, f"{sequence_id} · {title}", f"Secuencia disponible en el {term}.º periodo de planificación.", f"../{folder}/{sequence_folder}/📘 Guía docente/📘 Guía docente.md"))
    card_html = "\n".join(
        f'<a class="card" href="{quote(href, safe="/.")}"><span class="icon" aria-hidden="true">{html_lib.escape(icon)}</span><span><strong>{html_lib.escape(title)}</strong><small>{html_lib.escape(description)}</small></span></a>'
        for icon, title, description, href in cards
    )
    project_title = html_lib.escape(str(config.get("project", {}).get("title", "Proyecto docente")))
    panel = f"""<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PromptDocentes · {project_title}</title>
<style>
:root{{--ink:#20304a;--muted:#5d6b80;--paper:#f7f8fc;--card:#fff;--primary:#5b4ee8;--accent:#15a58b;--line:#dfe4ef}}
*{{box-sizing:border-box}}body{{margin:0;background:linear-gradient(145deg,#eef1ff,#f7fbfa 60%,#fff6e8);color:var(--ink);font:17px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif}}
main{{width:min(1080px,calc(100% - 32px));margin:40px auto 64px}}header{{padding:34px;border-radius:28px;background:linear-gradient(135deg,#4f46d9,#7668ef 58%,#159d8a);color:white;box-shadow:0 18px 50px #3d47822b}}
.eyebrow{{font-weight:750;letter-spacing:.08em;text-transform:uppercase;opacity:.86}}h1{{font-size:clamp(2rem,5vw,3.5rem);line-height:1.05;margin:.35rem 0 .8rem}}header p{{max-width:720px;margin:0;font-size:1.08rem}}h2{{margin:38px 0 16px;font-size:1.35rem}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px}}
.card{{display:flex;gap:15px;align-items:flex-start;padding:20px;border:1px solid var(--line);border-radius:18px;background:var(--card);color:inherit;text-decoration:none;box-shadow:0 8px 24px #46516d12;transition:.18s transform,.18s box-shadow}}
.card:hover,.card:focus-visible{{transform:translateY(-3px);box-shadow:0 14px 32px #46516d24;outline:3px solid #5b4ee84d;outline-offset:2px}}.icon{{display:grid;place-items:center;width:48px;height:48px;flex:0 0 48px;border-radius:14px;background:#f0efff;font-size:1.55rem}}strong,small{{display:block}}small{{margin-top:5px;color:var(--muted)}}
.notice{{margin-top:28px;padding:18px 20px;border-left:5px solid var(--accent);border-radius:12px;background:#eaf9f5}}footer{{margin-top:38px;color:var(--muted);font-size:.92rem}}@media(max-width:520px){{main{{margin-top:16px}}header{{padding:25px;border-radius:20px}}}}
</style></head><body><main>
<header><div class="eyebrow">PromptDocentes · Teacher MikeSL</div><h1>{project_title}</h1><p>Una entrada clara al mapa anual, las secuencias disponibles y las fuentes que sostienen el proyecto.</p></header>
<h2>🧭 Empieza aquí</h2><div class="grid">{card_html}</div>
<div class="notice"><strong>Antes de aplicar una secuencia</strong><span>Comprueba la duración real de las sesiones, los espacios, el material y las necesidades de acceso del grupo. La revisión profesional docente sigue siendo imprescindible.</span></div>
<footer>Vista generada desde los originales canónicos. Los iconos complementan las etiquetas de texto y no sustituyen su significado.</footer>
</main></body></html>"""
    (start / "🧭 Panel de navegación.html").write_text(panel, encoding="utf-8")
    copied += 1
    print(f"Vista docente creada: {presentation} ({copied} archivos copiados o generados)")
    return 0


def command_load_pack(args: argparse.Namespace) -> int:
    project = args.project.resolve()
    pack_path = args.pack.resolve()
    try:
        config = load_config(project)
        pack = json.loads(pack_path.read_text(encoding="utf-8"))
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: no se pudo cargar el paquete curricular: {exc}", file=sys.stderr)
        return 2

    required = ("pack_id", "verified_on", "context", "sources", "competencies", "evaluation_criteria", "core_learning")
    missing = [field for field in required if field not in pack]
    if missing:
        print("ERROR: faltan campos en el paquete: " + ", ".join(missing), file=sys.stderr)
        return 2

    def normalized(value: object) -> str:
        return re.sub(r"[^a-z0-9]", "", str(value).casefold().replace("ó", "o").replace("á", "a").replace("í", "i").replace("é", "e").replace("ú", "u").replace("ñ", "n"))

    project_context = config.get("context", {})
    pack_context = pack["context"]
    mismatches = []
    for field in ("territory", "stage", "level", "subject"):
        project_value = project_context.get(field, "")
        pack_value = pack_context.get(field, "")
        if normalized(project_value) != normalized(pack_value):
            mismatches.append(f"{field}: proyecto={project_value!r}, paquete={pack_value!r}")
    if mismatches:
        print("ERROR: el paquete curricular no coincide con el proyecto:", file=sys.stderr)
        for mismatch in mismatches:
            print(f"- {mismatch}", file=sys.stderr)
        return 2

    curriculum = config.setdefault("curriculum", {})
    curriculum.update({
        "pack_id": pack["pack_id"],
        "verified_on": pack["verified_on"],
        "sources": pack["sources"],
        "competencies": pack["competencies"],
        "evaluation_criteria": pack["evaluation_criteria"],
        "core_learning": pack["core_learning"],
    })
    write_json(project / CONTROL / "curso.json", config)
    with (project / CONTROL / "fuentes.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["id", "title", "url", "issuer", "scope", "status", "checked_on"])
        for source in pack["sources"]:
            writer.writerow([
                source.get("id", ""), source.get("title", ""), source.get("url", ""),
                source.get("issuer", ""), source.get("scope", ""), source.get("status", ""),
                source.get("checked_on", pack["verified_on"]),
            ])
    print(f"Paquete curricular cargado: {pack['pack_id']}")
    print(f"Competencias: {len(pack['competencies'])}; criterios: {len(pack['evaluation_criteria'])}")
    return 0


def command_export_map(args: argparse.Namespace) -> int:
    project = args.project.resolve()
    try:
        config = load_config(project)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    output = project / "10_diseno_anual" / "mapa-curricular.csv"
    output.parent.mkdir(parents=True, exist_ok=True)
    fields = (
        "id", "term", "title", "central_learning", "performance_or_product",
        "sessions", "competency_ids", "criterion_ids", "status",
    )
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for sequence in config.get("sequence_map", []):
            row = {field: sequence.get(field, "") for field in fields}
            row["competency_ids"] = ";".join(sequence.get("competency_ids", []))
            row["criterion_ids"] = ";".join(sequence.get("criterion_ids", []))
            writer.writerow(row)
    print(f"Mapa curricular exportado: {output}")
    return 0


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description=__doc__)
    sub = root.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="crear un proyecto vacío")
    init.add_argument("--project", type=Path, required=True)
    init.add_argument("--title", required=True)
    init.add_argument("--academic-year", required=True)
    init.add_argument("--owner", default="Teacher MikeSL")
    init.add_argument("--stage", required=True)
    init.add_argument("--level", required=True)
    init.add_argument("--subject", required=True)
    init.add_argument("--model", choices=("competency", "learning-outcomes", "objectives"), default="competency")
    init.set_defaults(func=command_init)

    status = sub.add_parser("status", help="mostrar el estado del proyecto")
    status.add_argument("--project", type=Path, required=True)
    status.set_defaults(func=command_status)

    validate = sub.add_parser("validate", help="validar la configuración y cobertura")
    validate.add_argument("--project", type=Path, required=True)
    validate.add_argument("--strict", action="store_true")
    validate.set_defaults(func=command_validate)

    manifest = sub.add_parser("manifest", help="crear un inventario con huellas SHA-256")
    manifest.add_argument("--project", type=Path, required=True)
    manifest.set_defaults(func=command_manifest)

    present = sub.add_parser("present", help="crear una vista docente ordenada con iconos")
    present.add_argument("--project", type=Path, required=True)
    present.set_defaults(func=command_present)

    load_pack = sub.add_parser("load-pack", help="cargar un paquete curricular verificado")
    load_pack.add_argument("--project", type=Path, required=True)
    load_pack.add_argument("--pack", type=Path, required=True)
    load_pack.set_defaults(func=command_load_pack)

    export_map = sub.add_parser("export-map", help="exportar el mapa anual a CSV")
    export_map.add_argument("--project", type=Path, required=True)
    export_map.set_defaults(func=command_export_map)
    return root


def main() -> int:
    args = parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
