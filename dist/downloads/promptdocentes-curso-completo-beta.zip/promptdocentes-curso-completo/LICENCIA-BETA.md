# Condiciones de evaluación privada

Copyright © 2026 Teacher MikeSL. Todos los derechos reservados.

Esta versión se facilita exclusivamente a participantes autorizados para probarla y comunicar observaciones. No se concede permiso para copiar, redistribuir, vender, sublicenciar, publicar, transformar ni integrar la skill, su código, sus plantillas o su documentación en otro producto.

Los recursos creados por cada docente a partir de sus propios datos y decisiones seguirán el régimen que determine ese docente, sin perjuicio de los derechos de terceros y de las condiciones aplicables a las fuentes incorporadas.

Los textos normativos, marcas, logotipos y materiales de terceros pertenecen a sus respectivos titulares y no quedan relicenciados por este documento.

La herramienta presta apoyo a la preparación docente. No garantiza por sí sola la vigencia normativa, la aprobación administrativa, la adecuación a un caso concreto ni la ausencia de errores. La persona usuaria debe revisar las fuentes oficiales y validar profesionalmente el resultado antes de utilizarlo o compartirlo.
